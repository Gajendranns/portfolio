# XAUUSD AI Trading Signal Bot

Signal-only trading decision system for XAUUSD (Gold) targeting the
VT Markets **MT5 Web Terminal**. It generates **signals for manual
execution** — it never sends orders, never auto-trades, and does not
claim validated live accuracy.

**Honesty policy (core to this project):**
- Signals computed from **synthetic test data** by default (clearly labeled).
- No fabricated live prices. No invented accuracy stats.
- Live mode is **disabled by default** and requires an authorized, verified
  data source (VT Markets does not expose a public retail market-data API;
  the `MetaTrader5` pip package needs a local MT5 *desktop* terminal, not
  the web terminal — see `docs/DATA_ACCESS` notes below).

## Strategy (multi-timeframe, signal-only)

- **H1** trend confirmation (EMA 20/50/200 + Swing structure + MACD/RSI).
- **M15** setup detection (CPR break/retest, bias).
- **M5** entry confirmation (≥ N consecutive candles agreeing with the bias).
- Rejection filters: spread ≤ 35 pts, ATR ≥ 15 pts, volatility OK.
- Exit plan: 2R reward, hard invalidation at H1 trend flip / opposite confirmation.

## Structure

```
backend/
  app/
    config.py              # Pydantic settings + dir resolution
    main.py                # FastAPI app factory
    api/routes.py          # /api endpoints
    data/                  # providers: csv (HISTORICAL/SYNTHETIC), broker (LIVE stub),
                           # validator, synthetic_generator
    indicators/            # technical, price_action, cpr
    strategy/              # trend, setup, risk, signal_engine
    backtest/              # engine + metrics (honest, cost-adjusted)
    database/              # SQLAlchemy models + repository (signal history)
    services/              # market_service, signal_service
  tests/                   # 56 tests (pytest)
frontend/
  React + TypeScript + Vite dashboard (candles, signal, history, backtest)
data/
  synthetic/               # generated test dataset (CSV + metadata.json)
```

## Run (Dev)

Backend (Python 3.10+):

```bash
cd backend
pip3 install --user -r requirements.txt      # no venv on this box
DATA_MODE=SYNTHETIC python3 -m uvicorn app.main:app --reload --port 8000
```

Frontend:

```bash
cd frontend
npm install
npm run dev        # http://localhost:5173  (proxies /api -> 127.0.0.1:8000)
```

Tests:

```bash
cd backend && python3 -m pytest tests -q
```

## Generate synthetic test data

```bash
cd backend
python3 -m app.data.synthetic_generator --days 14 --seed 42
# writes data/synthetic/XAUUSD_{M5,M15,H1}.csv + metadata.json
```

## API

| Endpoint | Method | Purpose |
| --- | --- | --- |
| `/api/health` | GET | liveness |
| `/api/data/status` | GET | current data source, freshness, mode |
| `/api/market/{symbol}` | GET | candles (M5/M15/H1), CPR, validation reports |
| `/api/signals/latest` | GET | latest signal (BUY/SELL/NO TRADE) + reasons |
| `/api/signals/history` | GET | stored signal history |
| `/api/settings` | GET | live indicator/filter/risk settings |
| `/api/backtest/run` | POST | simulated backtest with costs |

## Data modes

- `DATA_MODE=SYNTHETIC` — reads `data/synthetic`, labeled everywhere.
- `DATA_MODE=HISTORICAL` — reads `data/historical` (drop real exported CSVs here;
  must be clean, gap-validated, symbol_YYYY_MM.csv naming as documented).
- `DATA_MODE=LIVE` — requires a configured `BrokerProvider`; raises
  `NotConfiguredError` until an authorized source is wired in.

## Units (important)

XAUUSD: **1 point = 0.01 price units**. All thresholds and costs are
applied consistently via `POINT_SIZE = 0.01` in `signal_engine.py` and
the backtest engine (spread/slippage convert points → price units).

## Disclaimer

Educational tool. Not financial advice. Backtest results use synthetic
data and out-of-sample results will differ. Verify every signal on the
broker chart before trading.