"""CPR and daily-aggregation tests."""
from __future__ import annotations

import pandas as pd

from backend.app.indicators.cpr import (
    cpr_position,
    compute_cpr,
    daily_candles,
    previous_day_cpr,
)
from backend.app.data.synthetic_generator import aggregate_from_m5


def test_compute_cpr_known():
    cpr = compute_cpr(prev_high=110.0, prev_low=90.0, prev_close=100.0)
    assert cpr.pivot == pytest_approx(100.0)
    assert cpr.bc == pytest_approx(100.0)
    assert cpr.tc == pytest_approx(100.0)
    assert cpr.width == pytest_approx(0.0)


def test_cpr_position():
    cpr = compute_cpr(110.0, 80.0, 100.0)  # pivot=96.67, bc=95, tc=98.33
    assert cpr_position(100.0, cpr) == "above"
    assert cpr_position(90.0, cpr) == "below"
    assert cpr_position(97.0, cpr) == "inside"


def test_daily_aggregation_open_high_low_close():
    m5 = pd.DataFrame(
        {
            "open": [1, 2, 3, 4],
            "high": [2, 3, 4, 5],
            "low": [0.5, 1.5, 2.5, 3.5],
            "close": [1.5, 2.5, 3.5, 4.5],
            "volume": [1, 1, 1, 1],
            "spread": [0.1, 0.1, 0.1, 0.1],
        },
        index=pd.date_range("2026-01-01 23:50", periods=4, freq="5min", tz="UTC"),
    )
    daily = daily_candles(m5)
    assert len(daily) == 2  # two UTC days
    first = daily.iloc[0]
    assert first["open"] == 1 and first["close"] == 2.5
    assert first["high"] == 3 and first["low"] == 0.5
    assert first["volume"] == 2


def test_aggregate_m15_correct():
    idx = pd.date_range("2026-01-01", periods=6, freq="5min", tz="UTC")
    df = pd.DataFrame(
        {"open": [1, 2, 3, 4, 5, 6],
         "high": [1.5, 2.8, 3.9, 4.5, 5.6, 6.4],
         "low": [0.9, 1.8, 2.7, 3.6, 4.7, 5.8],
         "close": [1.2, 2.2, 3.2, 4.2, 5.2, 6.2],
         "volume": [1] * 6, "spread": [0.1] * 6},
        index=idx,
    )
    m15 = aggregate_from_m5(df, "M15")
    assert len(m15) == 2
    assert m15["open"].iloc[0] == 1
    assert m15["close"].iloc[0] == 3.2
    assert m15["high"].iloc[0] == 3.9
    assert m15["low"].iloc[0] == 0.9
    assert m15["volume"].iloc[0] == 3
    assert m15["open"].iloc[1] == 4


def test_incomplete_trailing_group_dropped():
    idx = pd.date_range("2026-01-01", periods=5, freq="5min", tz="UTC")
    df = pd.DataFrame(
        {"open": [1.0] * 5, "high": [2.0] * 5, "low": [0.0] * 5,
         "close": [1.5] * 5, "volume": [1.0] * 5, "spread": [0.1] * 5},
        index=idx,
    )
    m15 = aggregate_from_m5(df, "M15")  # 5 bars: one full group + 2 leftover
    assert len(m15) == 1


def test_previous_day_cpr():
    m5 = pd.DataFrame(
        {"open": [100.0], "high": [110.0], "low": [90.0],
         "close": [105.0], "volume": [1.0], "spread": [0.1]},
        index=pd.DatetimeIndex([pd.Timestamp("2026-01-01 12:00", tz="UTC")]),
    )
    cpr = previous_day_cpr(m5)
    assert cpr is not None
    assert cpr.pivot == pytest_approx(101.666, abs=1e-2)


from pytest import approx as pytest_approx