"""Indicator unit tests on known small samples."""
from __future__ import annotations

import pandas as pd
from pytest import approx as pytest_approx

from backend.app.indicators.technical import atr, ema, macd, rsi, add_core_indicators


def test_ema_known():
    s = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0])
    e = ema(s, 3)
    # first value equals first input (adjust=False)
    assert e.iloc[0] == pytest_approx(1.0)
    assert 4.0 < e.iloc[-1] < 5.0


def test_rsi_extremes():
    s = pd.Series(list(range(1, 30)), dtype="float")  # strictly rising
    r = rsi(s, 14)
    assert r.dropna().iloc[-1] == pytest_approx(100.0)
    s2 = pd.Series(list(range(30, 1, -1)), dtype="float")  # strictly falling
    r2 = rsi(s2, 14)
    assert r2.dropna().iloc[-1] == pytest_approx(0.0)


def test_macd_histogram_sign():
    rising = pd.Series([float(i) for i in range(1, 50)])
    m = macd(rising)
    # skip the first warm-up value (0) which equals signal
    assert (m["hist"].dropna().iloc[1:] > 0).all()
    falling = pd.Series([float(i) for i in range(50, 1, -1)])
    m2 = macd(falling)
    assert (m2["hist"].dropna().iloc[1:] < 0).all()


def test_atr_positive_and_bounded():
    idx = pd.date_range("2026-01-01", periods=40, freq="5min", tz="UTC")
    df = pd.DataFrame(
        {"open": 100.0, "high": 103.0, "low": 98.0, "close": 101.0},
        index=idx,
    )
    a = atr(df, 14)
    v = a.dropna().iloc[-1]
    assert v > 0
    assert 1.0 < v < 6.0


def test_core_columns_added(frames_utc):
    out = add_core_indicators(frames_utc)
    for col in ("ema_fast", "ema_mid", "ema_slow", "rsi", "macd",
                "macd_signal", "macd_hist", "atr"):
        assert col in out.columns
    assert out["rsi"].dropna().between(0, 100).all()
    assert (out["atr"].dropna() > 0).all()