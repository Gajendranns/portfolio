"""Pytest fixtures. Synthetic data built via the generator (labeled synthetic)."""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from backend.app.config import PROJECT_ROOT, Settings  # noqa: E402
from backend.app.data.csv_provider import CsvProvider  # noqa: E402
from backend.app.data.synthetic_generator import aggregate_from_m5, generate_m5  # noqa: E402
from backend.app.data.base import DataMode  # noqa: E402

# Run API tests against the project's generated synthetic dataset (clearly
# labeled SYNTHETIC_TEST_DATA). LIVE mode is never used in tests.
os.environ.setdefault("DATA_MODE", "SYNTHETIC")
os.environ.setdefault("SYNTHETIC_DIR", str(PROJECT_ROOT / "data" / "synthetic"))
os.environ.setdefault("HISTORICAL_DIR", str(PROJECT_ROOT / "data" / "synthetic"))
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")


@pytest.fixture(scope="session")
def synthetic_dir(tmp_path_factory):
    d = tmp_path_factory.mktemp("synthetic")
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=10)
    start = start.replace(second=0, microsecond=0)
    while start.minute % 5:
        start += timedelta(minutes=1)
    m5 = generate_m5(start=start, end=end, initial_price=2300.0, seed=42)
    M15 = aggregate_from_m5(m5, "M15")
    H1 = aggregate_from_m5(m5, "H1")
    m5.to_csv(d / "XAUUSD_M5.csv")
    M15.to_csv(d / "XAUUSD_M15.csv")
    H1.to_csv(d / "XAUUSD_H1.csv")
    import json
    (d / "metadata.json").write_text(
        json.dumps({"dataset": "SYNTHETIC_TEST_DATA", "seed": 42})
    )
    return str(d)


@pytest.fixture()
def frames_utc():
    df = generate_m5(
        start=datetime(2026, 1, 1, 0, 0, tzinfo=timezone.utc),
        end=datetime(2026, 1, 10, 0, 0, tzinfo=timezone.utc),
        initial_price=2000.0, seed=7,
    )
    return df


@pytest.fixture()
def synthetic_settings(synthetic_dir) -> Settings:
    return Settings(
        data_mode="SYNTHETIC",
        synthetic_dir=synthetic_dir,
        historical_dir=synthetic_dir,
        database_url="sqlite:///:memory:",
    )


@pytest.fixture()
def synthetic_provider(synthetic_dir) -> CsvProvider:
    return CsvProvider(synthetic_dir, DataMode.SYNTHETIC)


def make_timeframes(n_days=12, seed=11, initial=2300.0):
    end = datetime(2026, 3, 1, 12, 0, tzinfo=timezone.utc)
    start = end - timedelta(days=n_days)
    m5 = generate_m5(start=start, end=end, initial_price=initial, seed=seed)
    return m5, aggregate_from_m5(m5, "M15"), aggregate_from_m5(m5, "H1")