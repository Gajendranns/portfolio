"""Risk management tests."""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from backend.app.strategy.risk import (
    ContractSpec,
    RiskTracker,
    build_trade_plan,
    position_size,
)


def test_trade_plan_buy():
    plan = build_trade_plan(direction="BUY", entry=100.0, atr=2.0,
                            atr_stop_multiplier=1.5, reward_risk=2.0)
    assert plan.stop_loss == 100.0 - 3.0
    assert plan.take_profit == 100.0 + 6.0
    assert plan.risk_reward == 2.0


def test_trade_plan_sell():
    plan = build_trade_plan(direction="SELL", entry=100.0, atr=2.0,
                            atr_stop_multiplier=1.5, reward_risk=2.0)
    assert plan.stop_loss == 100.0 + 3.0
    assert plan.take_profit == 100.0 - 6.0


def test_trade_plan_rejects_bad_atr():
    with pytest.raises(ValueError):
        build_trade_plan(direction="BUY", entry=100.0, atr=0.0)


def test_position_size_default_spec():
    spec = ContractSpec()
    out = position_size(equity=10000.0, risk_percent=0.5, stop_distance=4.0,
                        spec=spec)
    # risk 50 usd; per lot risk = 4.0 * 100 = 400 -> 0.125 lots -> rounded 0.13
    assert out["lots"] > 0
    assert out["risk_amount"] == pytest_approx(50.0)
    assert "Default XAUUSD specs" in out["spec"]["note"]


def test_risk_tracker_loss_limit():
    rt = RiskTracker(max_daily_loss_percent=2.0, starting_equity=1000.0)
    t1 = datetime(2026, 1, 1, 10, 0, tzinfo=timezone.utc)
    rt.record_result(-10.0, t1)
    assert not rt.daily_loss_limit_hit(datetime(2026, 1, 1, 11, 0, tzinfo=timezone.utc))
    rt.record_result(-10.0, datetime(2026, 1, 1, 11, 0, tzinfo=timezone.utc))
    assert rt.daily_loss_limit_hit(datetime(2026, 1, 1, 12, 0, tzinfo=timezone.utc))


def test_risk_tracker_consecutive_losses():
    rt = RiskTracker(max_consecutive_losses=3)
    rt.record_result(-5)
    rt.record_result(-5)
    assert not rt.blocked_reasons()
    rt.record_result(-5)
    assert any("Consecutive loss" in r for r in rt.blocked_reasons())
    rt.record_result(10)
    assert rt.blocked_reasons() == []


def test_duplicate_signal_prevention():
    key = RiskTracker.signal_key("XAUUSD", "M5", "BUY", "2026-01-01T00:00")
    rt = RiskTracker()
    assert not rt.is_duplicate(key)
    rt.register(key)
    assert rt.is_duplicate(key)


from pytest import approx as pytest_approx