"""Backtest engine + metrics tests (no look-ahead, costs, collision)."""
from __future__ import annotations

from backend.app.backtest.engine import BacktestConfig, run_backtest
from backend.app.backtest.metrics import compute_metrics, TradeRecord
from tests.conftest import make_timeframes


def test_backtest_runs_on_synthetic(synthetic_settings):
    m5, m15, h1 = make_timeframes(n_days=8, seed=11)
    res = run_backtest(
        m5=m5, m15=m15, h1=h1, settings=synthetic_settings,
        cfg=BacktestConfig(symbol="XAUUSD", spread_points=20, slippage_points=5),
        data_mode="SYNTHETIC", data_source="synth",
    )
    m = res.metrics
    assert m.total_trades >= 0
    assert all(
        "Simulated results only" in w for w in res.warnings
    ) or len(res.warnings) >= 2
    if m.total_trades:
        assert 0.0 <= m.win_rate <= 1.0
        assert m.net_pnl_after_costs <= m.net_pnl + 1e-9  # costs reduce net
        assert m.max_consecutive_losses >= 0
        assert m.expectancy == pytest_approx(m.net_pnl_after_costs / m.total_trades)


def test_no_lookahead_entry_before_exit(synthetic_settings):
    m5, m15, h1 = make_timeframes(n_days=8, seed=11)
    res = run_backtest(
        m5=m5, m15=m15, h1=h1, settings=synthetic_settings,
        cfg=BacktestConfig(symbol="XAUUSD", spread_points=20, slippage_points=5),
        data_mode="SYNTHETIC", data_source="synth",
    )
    for t in res.trades:
        assert t.entry_time <= t.exit_time
        if t.status == "sl":
            assert (t.exit_price <= t.entry_price) if t.side == "BUY" else (t.exit_price >= t.entry_price)
        if t.status == "tp":
            assert (t.exit_price >= t.entry_price) if t.side == "BUY" else (t.exit_price <= t.entry_price)


def test_collision_resolved_as_stop(synthetic_settings):
    m5, m15, h1 = make_timeframes(n_days=8, seed=11)
    res = run_backtest(
        m5=m5, m15=m15, h1=h1, settings=synthetic_settings,
        cfg=BacktestConfig(symbol="XAUUSD", spread_points=20, slippage_points=5),
        data_mode="SYNTHETIC", data_source="synth",
    )
    # all statuses must be one of tp/sl/time_exit
    for t in res.trades:
        assert t.status in ("tp", "sl", "time_exit")


def test_metrics_empty_is_safe():
    m = compute_metrics([])
    assert m.total_trades == 0
    assert m.win_rate == 0.0


def test_metrics_known_values():
    trades = [
        TradeRecord("BUY", "a", "b", 100, 110, 10, 9.5, "tp", "bullish"),
        TradeRecord("SELL", "a", "b", 100, 90, 10, 9.5, "tp", "bearish"),
        TradeRecord("BUY", "a", "b", 100, 96, -4, -4.5, "sl", "bullish"),
    ]
    m = compute_metrics(trades)
    assert m.total_trades == 3
    assert m.win_rate == pytest_approx(2 / 3)
    assert m.profit_factor == pytest_approx(19.0 / 4.5)
    assert m.net_pnl_after_costs == pytest_approx(14.5)
    assert m.by_condition["bullish"]["trades"] == 2
    assert m.by_side["BUY"]["trades"] == 2


from pytest import approx as pytest_approx