"""Tests for the candle validator (Phase 4)."""
from __future__ import annotations

import pandas as pd
import pytest

from backend.app.data.validator import validate_candles


def okframe():
    idx = pd.date_range("2026-01-01", periods=6, freq="5min", tz="UTC")
    return pd.DataFrame(
        {"open": [100.0] * 6, "high": [102.0] * 6, "low": [99.0] * 6,
         "close": [101.0] * 6, "volume": [1.0] * 6, "spread": [0.2] * 6},
        index=idx,
    )


def test_valid_frame_passes():
    rep = validate_candles(okframe(), "M5")
    assert rep.is_valid
    assert rep.n_output == 6
    assert rep.errors == []


def test_empty_frame_invalid():
    rep = validate_candles(None, "M5")
    assert not rep.is_valid
    assert rep.errors


def test_ohlc_relation_violation_rejected():
    df = okframe()
    df.loc[df.index[2], "high"] = 90.0  # high < close/low/open
    rep = validate_candles(df, "M5")
    assert rep.n_invalid_ohlc == 1
    assert rep.n_output == 5
    assert any("INVALID" in e or "invalid" in e.lower() for e in rep.errors)


def test_duplicate_timestamps_removed():
    df = okframe()
    df = pd.concat([df, df.iloc[[3]]])
    rep = validate_candles(df, "M5")
    assert rep.n_duplicates == 1
    assert rep.n_output == 6
    assert any("duplicate" in w.lower() for w in rep.warnings)


def test_unsorted_is_sorted():
    df = okframe()
    df = df.iloc[::-1]
    rep = validate_candles(df, "M5")
    assert rep.is_valid
    assert rep.df.index.is_monotonic_increasing


def test_naive_timezone_assumed_utc():
    df = okframe()
    df.index = df.index.tz_localize(None)
    rep = validate_candles(df, "M5")
    assert rep.timezone == "UTC"
    assert any("assumed UTC" in w for w in rep.warnings)


def test_gap_detected():
    df = okframe()
    idx = list(df.index)
    df = df.drop(idx[2])  # creates a gap of one missing M5 candle
    rep = validate_candles(df, "M5", max_gap_factor=1.9)
    assert rep.n_gaps == 1


def test_nonpositive_price_rejected():
    df = okframe()
    df.loc[df.index[1], "open"] = -5.0
    rep = validate_candles(df, "M5")
    assert rep.n_invalid_ohlc == 1

def test_nan_ohlc_rejected():
    df = okframe()
    df.loc[df.index[4], "close"] = float("nan")
    rep = validate_candles(df, "M5")
    assert rep.n_invalid_ohlc == 1