"""Synthetic generator + separation tests."""
from __future__ import annotations

import json

import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from backend.app.data.base import DataMode
from backend.app.data.csv_provider import CsvProvider
from backend.app.data.synthetic_generator import (
    SYNTHETIC_LABEL,
    aggregate_from_m5,
    generate_m5,
    main,
    write_dataset,
)

START = pd.Timestamp("2026-01-01", tz="UTC")
END2 = pd.Timestamp("2026-01-03", tz="UTC")


def test_reproducible_same_seed():
    a = generate_m5(start=START, end=END2, initial_price=2300.0, seed=42)
    b = generate_m5(start=START, end=END2, initial_price=2300.0, seed=42)
    assert_frame_equal(a, b)


def test_different_seed_differs():
    a = generate_m5(start=START, end=END2, initial_price=2300.0, seed=1)
    b = generate_m5(start=START, end=END2, initial_price=2300.0, seed=2)
    assert (a != b).any().any()


def test_ohlc_relationships_hold(frames_utc):
    df = frames_utc
    assert (df["high"] >= df[["open", "close", "low"]].max(axis=1)).all()
    assert (df["low"] <= df[["open", "close", "high"]].min(axis=1)).all()
    assert (df[["open", "high", "low", "close"]] > 0).all().all()


def test_timestamps_ordered_unique(frames_utc):
    assert frames_utc.index.is_monotonic_increasing
    assert frames_utc.index.is_unique


def test_aggregation_matches_table(frames_utc):
    m15 = aggregate_from_m5(frames_utc, "M15")
    h1 = aggregate_from_m5(frames_utc, "H1")
    assert len(m15) == len(frames_utc) // 3
    assert len(h1) == len(frames_utc) // 12
    row = m15.iloc[0]
    chunk = frames_utc.iloc[:3]
    assert row["open"] == chunk["open"].iloc[0]
    assert row["high"] == chunk["high"].max()
    assert row["low"] == chunk["low"].min()
    assert row["close"] == chunk["close"].iloc[-1]
    assert row["volume"] == chunk["volume"].sum()


def test_write_dataset_labels_synthetic(tmp_path):
    summary = write_dataset(
        start=START, end=END2, initial_price=2300.0, seed=3,
        output_dir=str(tmp_path),
    )
    meta = json.loads((tmp_path / "metadata.json").read_text())
    assert meta["dataset"] == SYNTHETIC_LABEL
    for tf, path in summary["files"].items():
        assert not pd.read_csv(path).empty


def test_refuses_overwrite_without_force(tmp_path):
    write_dataset(start=START, end=END2, initial_price=2300.0, seed=3,
                  output_dir=str(tmp_path))
    with pytest.raises(RuntimeError):
        write_dataset(start=START, end=END2, initial_price=2300.0, seed=4,
                      output_dir=str(tmp_path))


def test_csv_provider_labels_synthetic(synthetic_dir):
    p = CsvProvider(synthetic_dir, DataMode.SYNTHETIC)
    st = p.get_data_source_status("XAUUSD")
    assert st.mode == DataMode.SYNTHETIC
    assert any("Synthetic" in w for w in st.warnings)


def test_cli_prints_files(capsys, tmp_path):
    rc = main(["--days", "2", "--seed", "9", "--force",
               "--output-dir", str(tmp_path / "syn-cli")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "SYNTHETIC_TEST_DATA" in out
    assert "metadata" in out