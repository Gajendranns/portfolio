"""Signal-engine tests: structure, agreement, filters, invalidation."""
from __future__ import annotations

from backend.app.config import Settings
from backend.app.data.base import DataMode
from backend.app.indicators.cpr import previous_day_cpr
from backend.app.indicators.technical import add_core_indicators
from backend.app.strategy.signal_engine import evaluate_signal
from tests.conftest import make_timeframes


def _settings(**kw) -> Settings:
    base = dict(
        data_mode="SYNTHETIC", database_url="sqlite:///:memory:",
        max_spread_points=35.0, min_atr_points=15.0, max_atr_points=1000.0,
        m5_confirm_threshold=2,
    )
    base.update(kw)
    return Settings(**base)


def _run(m5, m15, h1, settings, spread=0.20):
    m5i, m15i, h1i = add_core_indicators(m5), add_core_indicators(m15), add_core_indicators(h1)
    return evaluate_signal(
        symbol="XAUUSD", h1_i=h1i, m15_i=m15i, m5_i=m5i,
        cpr=previous_day_cpr(m15),
        data_mode=DataMode.SYNTHETIC, data_source="synth",
        quote={"spread": spread, "live": False},
        settings=settings,
    )


def test_invalid_data_returns_structured_no_trade():
    s = _settings()
    m5, m15, h1 = make_timeframes(n_days=1, seed=5)
    import pandas as pd
    sig = _run(m5.iloc[:40], m15, h1, s)  # not enough M5 candles
    assert sig.signal == "NO TRADE"
    d = sig.to_dict()
    assert d["signal"] == "NO TRADE"
    assert isinstance(d["rejection_reasons"], list) and d["rejection_reasons"]
    assert d["confidence_label"].startswith("uncalibrated")


def test_engine_returns_valid_structure_on_good_data():
    s = _settings()
    m5, m15, h1 = make_timeframes(n_days=20, seed=11)
    sig = _run(m5, m15, h1, s)
    d = sig.to_dict()
    assert d["signal"] in ("BUY", "SELL", "NO TRADE")
    assert d["data_mode"] == "SYNTHETIC"
    for k in ("symbol", "signal_timestamp", "data_timestamp", "h1_trend"):
        assert k in d
    if d["signal"] != "NO TRADE":
        assert d["entry"] and d["stop_loss"] and d["take_profit"]
        assert d["risk_reward"] >= 1
        assert d["expiry"] and d["invalidation_conditions"]


def test_high_spread_rejected():
    s = _settings(max_spread_points=10.0)
    m5, m15, h1 = make_timeframes(n_days=20, seed=11)
    sig = _run(m5, m15, h1, s, spread=0.50)  # 50 points > 10
    assert sig.signal == "NO TRADE"
    assert any("Spread" in r for r in sig.rejection_reasons)


def _bearish_h1(n=200):
    import pandas as pd
    idx = pd.date_range("2026-01-01", periods=n, freq="1h", tz="UTC")
    closes = [2500.0 - 0.5 * i for i in range(n)]
    opens = [2500.0] + closes[:-1]
    return pd.DataFrame(
        {"open": opens, "high": [c * 1.001 for c in closes],
         "low": [c * 0.999 for c in closes], "close": closes,
         "volume": [1.0] * n, "spread": [0.2] * n},
        index=idx,
    )


def test_conflicting_timeframes_no_trade():
    s = _settings()
    m5, m15, h1 = make_timeframes(n_days=20, seed=11)
    h1 = _bearish_h1()
    sig = _run(m5, m15, h1, s)
    assert sig.signal == "NO TRADE"


def test_low_atr_rejected():
    s = _settings(min_atr_points=5000.0)  # absurdly high minimum (~50 price)
    m5, m15, h1 = make_timeframes(n_days=20, seed=11)
    sig = _run(m5, m15, h1, s)
    assert sig.signal == "NO TRADE"
    assert any("ATR" in r for r in sig.rejection_reasons)