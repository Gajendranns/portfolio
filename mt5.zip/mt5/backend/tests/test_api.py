"""API endpoint tests (run in SYNTHETIC mode; see conftest)."""
from __future__ import annotations

from fastapi.testclient import TestClient

from backend.app.main import app
from backend.app.config import Settings

client = TestClient(app)


def test_health():
    assert client.get("/api/health").status_code == 200


def test_settings_endpoint():
    r = client.get("/api/settings")
    assert r.status_code == 200
    d = r.json()
    assert d["symbol"] == "XAUUSD"
    assert d["data_mode"] in ("SYNTHETIC", "HISTORICAL", "LIVE")
    assert "disclaimer" in d


def test_data_status_reports_mode():
    r = client.get("/api/data/status")
    assert r.status_code == 200
    d = r.json()
    assert "mode" in d
    assert "symbol" in d


def test_market_endpoint_validates_symbol():
    r = client.get("/api/market/XAUUSD")
    assert r.status_code == 200
    d = r.json()
    assert d["symbol"] == "XAUUSD"
    assert len(d["mode"]) > 0
    assert set(d["candles"]).issuperset({"M5", "M15", "H1"})


def test_market_endpoint_rejects_unknown_symbol():
    r = client.get("/api/market/NOTAREALSYMBOL")
    assert r.status_code == 404


def test_latest_signal_structured():
    r = client.get("/api/signals/latest")
    assert r.status_code == 200
    d = r.json()["latest"]
    assert d["signal"] in ("BUY", "SELL", "NO TRADE")
    assert "confidence_label" in d and "uncalibrated" in d["confidence_label"]
    assert "rejection_reasons" in d


def test_signal_history():
    r = client.get("/api/signals/history")
    assert r.status_code == 200
    assert isinstance(r.json()["history"], list)


def test_backtest_endpoints(synthetic_settings):
    r = client.post("/api/backtest/run",
                    json={"spread_points": 20, "slippage_points": 5})
    assert r.status_code == 200
    d = r.json()
    assert "metrics" in d
    assert "disclaimer" in d["metrics"]
    r2 = client.get("/api/backtest/summary")
    assert r2.status_code == 200
    assert isinstance(r2.json()["runs"], list)


def test_synthetic_mode_warning_marked():
    s = Settings(data_mode="SYNTHETIC")
    # direct provider check
    from backend.app.services.market_service import MarketService
    mkt = MarketService(s)
    st = mkt.get_data_status("XAUUSD")
    if st.available:
        assert st.mode.value == "SYNTHETIC"


def test_invalid_datetime_returns_422():
    r = client.post("/api/backtest/run", json={"from_time": "not-a-date"})
    assert r.status_code == 422