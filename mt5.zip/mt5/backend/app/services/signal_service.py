"""Signal service: latest signal, history, evaluation."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from ..config import Settings
from ..data.base import DataMode, NotConfiguredError
from ..database.repository import Repository
from ..indicators.cpr import previous_day_cpr
from ..strategy.risk import RiskTracker
from ..strategy.signal_engine import Signal, generate_signal
from .market_service import MarketService


class SignalService:
    def __init__(
        self,
        settings: Settings,
        market: MarketService,
        repo: Repository,
    ) -> None:
        self.settings = settings
        self.market = market
        self.repo = repo
        # in-memory paper results tracker (not persisted across restarts yet)
        self.risk_tracker = RiskTracker(
            max_daily_loss_percent=settings.max_daily_loss_percent,
            max_consecutive_losses=settings.max_consecutive_losses,
        )

    def latest_signal(self, symbol: Optional[str] = None) -> Signal:
        symbol = (symbol or self.settings.symbol).upper()
        snap = self.market.get_full_snapshot(symbol)
        status = self.market.get_data_status(symbol)

        mode = DataMode(status.mode) if status.mode else self.settings.data_mode
        if not status.available and mode is not DataMode.SYNTHETIC:
            return Signal(
                symbol=symbol, signal="NO TRADE",
                signal_timestamp=datetime.now().isoformat(),
                data_timestamp=None, data_source=status.provider,
                data_mode=mode.value,
                h1_trend=None, m15_bias=None, m15_setup=None,
                entry=None, stop_loss=None, take_profit=None, risk_reward=None,
                indicator_values={}, spread=None, atr=None,
                confidence=0.0,
                confidence_label="uncalibrated heuristic score - not a probability",
                expiry=None, invalidation_conditions=[],
                rejection_reasons=[
                    f"Data unavailable: {status.detail}",
                    f"Mode is {mode.value}; no live prices are fabricated.",
                ],
            )

        sig = generate_signal(
            symbol=symbol,
            h1=snap["frames"]["H1"],
            m15=snap["frames"]["M15"],
            m5=snap["frames"]["M5"],
            cpr=previous_day_cpr(snap["frames"]["M15"]),
            data_mode=mode,
            data_source=status.provider,
            quote=snap["quote"],
            settings=self.settings,
            risk_tracker=self.risk_tracker,
        )
        try:
            if mode is not DataMode.SYNTHETIC:
                self.repo.insert_signal(sig.to_dict())
        except Exception:
            pass  # never crash the dashboard because of local persistence
        return sig

    def history(self, limit: int = 50) -> list[dict]:
        return self.repo.list_signals(limit=limit)

    def record_simulated_result(self, pnl: float) -> dict:
        self.risk_tracker.record_result(pnl)
        return {
            "equity": round(self.risk_tracker.equity, 2),
            "daily_pnl": round(self.risk_tracker.daily_pnl(), 2),
            "consecutive_losses": self.risk_tracker.consecutive_losses,
            "blocked": self.risk_tracker.blocked_reasons(),
        }