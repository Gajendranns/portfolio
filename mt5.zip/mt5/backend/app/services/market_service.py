"""Market data service: provider selection, snapshot assembly, status."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

import pandas as pd

from ..config import Settings
from ..data.base import DataMode, DataSourceStatus, empty_frame
from ..data.broker_provider import BrokerProvider
from ..data.csv_provider import CsvProvider
from ..data.validator import ValidationReport, validate_candles
from ..indicators.cpr import CPR, previous_day_cpr

TIMEFRAMES = ["M5", "M15", "H1"]


class MarketService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.provider = self._build_provider(settings)

    def _build_provider(self, settings: Settings):
        mode = DataMode(settings.data_mode)
        if mode == DataMode.SYNTHETIC:
            return CsvProvider(
                settings.synthetic_dir, DataMode.SYNTHETIC, settings.symbol,
                source_label="SYNTHETIC",
            )
        if mode == DataMode.LIVE:
            return BrokerProvider(
                settings.live_provider, settings.live_api_base_url,
                settings.live_api_key, settings.symbol,
            )
        return CsvProvider(
            settings.historical_dir, DataMode.HISTORICAL, settings.symbol,
            source_label="historical-csv",
        )

    # ------------------------------------------------------------------ data
    def get_candles(self, symbol: str, timeframe: str) -> tuple[pd.DataFrame, ValidationReport]:
        df = self.provider.get_historical_candles(symbol, timeframe)
        rep = validate_candles(df, timeframe)
        return (rep.df if rep.df is not None else empty_frame()), rep

    def get_full_snapshot(self, symbol: Optional[str] = None) -> dict:
        symbol = (symbol or self.settings.symbol).upper()
        frames, reports, cp = {}, {}, None
        meta = {}
        for tf in TIMEFRAMES:
            df, rep = self.get_candles(symbol, tf)
            frames[tf] = df
            reports[tf] = rep.to_dict()
            meta[tf] = {
                "n_candles": len(df),
                "first_time": df.index[0].isoformat() if len(df) else None,
                "last_time": df.index[-1].isoformat() if len(df) else None,
                "valid": rep.is_valid,
            }
        if len(frames["M15"]):
            cp = previous_day_cpr(frames["M15"])
        quote = self.provider.get_current_quote(symbol)
        return {
            "symbol": symbol,
            "frames": frames,
            "reports": reports,
            "cpr": cp.to_dict() if cp else None,
            "quote": quote,
            "meta": meta,
        }

    def get_data_status(self, symbol: Optional[str] = None) -> DataSourceStatus:
        return self.provider.get_data_source_status(symbol)

    # optimization: provider may cache frames; keep read-only here
    def provider_name(self) -> str:
        return self.provider.name