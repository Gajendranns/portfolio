"""FastAPI application entrypoint (local only)."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api.routes import router
from .config import get_settings

settings = get_settings()
app = FastAPI(
    title="XAUUSD Signal Bot",
    description=(
        "Signal-only tool. Never places trades. Synthetic/historical data "
        "must never be presented as live."
    ),
    version="0.1.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)


@app.get("/")
def root() -> dict:
    return {
        "name": "XAUUSD Signal Bot",
        "mode": settings.data_mode,
        "endpoints": [
            "/api/health",
            "/api/data/status",
            "/api/market/{symbol}",
            "/api/signals/latest",
            "/api/signals/history",
            "/api/backtest/run",
            "/api/backtest/summary",
            "/api/settings",
        ],
        "disclaimer": "Signal-only; no automatic execution. Synthetic data is "
                      "clearly labeled and never used as live prices.",
    }