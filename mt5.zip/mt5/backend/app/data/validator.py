"""Candle validation (Phase 4).

Rules enforced:
  * timestamps must be tz-aware and represent UTC
  * OHLC must be numeric and positive
  * high >= open, close, low
  * low  <= open, close, high
  * duplicate timestamps removed
  * chronological order enforced
  * missing candles / gaps reported
  * stale data flagged

Invalid rows are dropped and the reason recorded; the report explains why.
No look-ahead is performed here, but callers must only use completed candles.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional

import pandas as pd

from .base import TIMEFRAME_MINUTES, validate_timeframe

_PRICE_TOL = 1e-9


@dataclass
class ValidationReport:
    is_valid: bool = True
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    n_input: int = 0
    n_output: int = 0
    n_duplicates: int = 0
    n_invalid_ohlc: int = 0
    n_gaps: int = 0
    first_time: Optional[datetime] = None
    last_time: Optional[datetime] = None
    timezone: str = "unknown"
    df: Optional[pd.DataFrame] = None

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "n_input": self.n_input,
            "n_output": self.n_output,
            "n_duplicates": self.n_duplicates,
            "n_invalid_ohlc": self.n_invalid_ohlc,
            "n_gaps": self.n_gaps,
            "first_time": self.first_time.isoformat() if self.first_time else None,
            "last_time": self.last_time.isoformat() if self.last_time else None,
            "timezone": self.timezone,
        }


def validate_candles(
    df: pd.DataFrame,
    timeframe: str,
    *,
    max_gap_factor: float = 3.0,
    now: Optional[datetime] = None,
) -> ValidationReport:
    """Validate and clean a candle frame. Returns a report carrying ``.df``."""
    tf = validate_timeframe(timeframe)
    rep = ValidationReport()
    if df is None or len(df) == 0:
        rep.is_valid = False
        rep.errors.append("No candles supplied.")
        rep.df = df
        return rep

    rep.n_input = len(df)
    work = df.copy()

    # ---- index / timezone ----
    if not isinstance(work.index, pd.DatetimeIndex):
        rep.is_valid = False
        rep.errors.append("Index is not a DatetimeIndex.")
        rep.df = work
        return rep
    if work.index.tz is None:
        rep.warnings.append(
            "Timestamps were tz-naive; assumed UTC. Confirm the source "
            "documentation (UTC vs broker-server time)."
        )
        work.index = work.index.tz_localize("UTC")
    else:
        work.index = work.index.tz_convert("UTC")
    rep.timezone = "UTC"
    work.index.name = "time"

    # ---- numeric OHLC ----
    for col in ("open", "high", "low", "close"):
        if col not in work.columns:
            rep.is_valid = False
            rep.errors.append(f"Missing required column: {col}")
            rep.df = work
            return rep
        work[col] = pd.to_numeric(work[col], errors="coerce")

    if "volume" not in work.columns:
        work["volume"] = pd.NA
    if "spread" not in work.columns:
        work["spread"] = pd.NA
    work["volume"] = pd.to_numeric(work["volume"], errors="coerce")
    work["spread"] = pd.to_numeric(work["spread"], errors="coerce")

    # ---- duplicate timestamps ----
    dup_mask = work.index.duplicated(keep="last")
    rep.n_duplicates = int(dup_mask.sum())
    if rep.n_duplicates:
        work = work[~dup_mask]
        rep.warnings.append(
            f"Removed {rep.n_duplicates} duplicate timestamp(s), kept last."
        )

    # ---- chronological order ----
    if not work.index.is_monotonic_increasing:
        work = work.sort_index()
        rep.warnings.append("Candles were not chronological; sorted ascending.")

    # ---- validity mask ----
    nan_mask = work[["open", "high", "low", "close"]].isna().any(axis=1)
    positive = (work[["open", "high", "low", "close"]] > 0).all(axis=1)
    high_ok = (
        work["high"] + _PRICE_TOL
        >= work[["open", "close", "low"]].max(axis=1)
    )
    low_ok = (
        work["low"] - _PRICE_TOL
        <= work[["open", "close", "high"]].min(axis=1)
    )
    valid_ohlc = (~nan_mask) & positive & high_ok & low_ok

    rep.n_invalid_ohlc = int((~valid_ohlc).sum())
    if rep.n_invalid_ohlc:
        bad_idx = work.index[~valid_ohlc]
        rep.errors.append(
            f"Dropped {rep.n_invalid_ohlc} invalid candle(s) "
            f"(NaN/non-positive/OHLC-relation violation). "
            f"First bad timestamp: {bad_idx[0]}."
        )
        work = work[valid_ohlc]

    # ---- gaps ----
    if len(work) >= 2:
        step = pd.Timedelta(minutes=TIMEFRAME_MINUTES[tf])
        deltas = work.index.to_series().diff().dropna()
        gap_mask = deltas > step * max_gap_factor
        rep.n_gaps = int(gap_mask.sum())
        if rep.n_gaps:
            rep.warnings.append(
                f"Detected {rep.n_gaps} gap(s) larger than "
                f"{max_gap_factor:g}x the {tf} interval (weekends/holidays "
                f"or missing candles). Verify against the source."
            )

    rep.n_output = len(work)
    if rep.n_output:
        rep.first_time = work.index[0].to_pydatetime()
        rep.last_time = work.index[-1].to_pydatetime()

    if rep.n_output == 0:
        rep.is_valid = False
        rep.errors.append("No valid candles remained after validation.")

    rep.df = work
    return rep


def detect_stale(
    df: pd.DataFrame,
    timeframe: str,
    *,
    now: Optional[datetime] = None,
    max_age_factor: float = 2.0,
) -> bool:
    """True if the newest candle is older than expected for the timeframe."""
    if df is None or len(df) == 0:
        return True
    tf = validate_timeframe(timeframe)
    now = now or datetime.now(timezone.utc)
    age = now - df.index[-1].to_pydatetime()
    return age > pd.Timedelta(minutes=TIMEFRAME_MINUTES[tf] * max_age_factor)
