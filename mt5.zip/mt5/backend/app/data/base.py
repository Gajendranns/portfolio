"""Market-data provider interface.

Every provider returns OHLCV(+spread) candles as a pandas DataFrame with:

    index : DatetimeIndex, tz-aware UTC, name="time", strictly increasing
    cols  : open, high, low, close, volume, spread

`volume` and `spread` may be all-NaN when the source does not provide them.
No provider may fabricate data. The base class never invents prices.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

import pandas as pd

CANDLE_COLUMNS = ["open", "high", "low", "close", "volume", "spread"]


class DataMode(str, Enum):
    SYNTHETIC = "SYNTHETIC"
    HISTORICAL = "HISTORICAL"
    LIVE = "LIVE"


TIMEFRAME_RULE = {
    "M1": "1min",
    "M5": "5min",
    "M15": "15min",
    "M30": "30min",
    "H1": "1h",
    "H4": "4h",
    "D1": "1D",
}

TIMEFRAME_MINUTES = {
    "M1": 1, "M5": 5, "M15": 15, "M30": 30,
    "H1": 60, "H4": 240, "D1": 1440,
}


def validate_timeframe(timeframe: str) -> str:
    tf = timeframe.strip().upper()
    if tf not in TIMEFRAME_RULE:
        raise ValueError(f"Unsupported timeframe: {timeframe!r}")
    return tf


def empty_frame() -> pd.DataFrame:
    idx = pd.DatetimeIndex([], name="time", tz="UTC")
    return pd.DataFrame(columns=CANDLE_COLUMNS, index=idx, dtype="float64")


@dataclass
class DataSourceStatus:
    """Machine-readable health/status of a provider."""

    provider: str
    mode: DataMode
    available: bool
    symbol: str
    last_candle_time: Optional[datetime] = None
    last_update_time: Optional[datetime] = None
    is_stale: bool = False
    fresh: bool = False
    detail: str = ""
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "provider": self.provider,
            "mode": self.mode.value,
            "available": self.available,
            "symbol": self.symbol,
            "last_candle_time": _iso(self.last_candle_time),
            "last_update_time": _iso(self.last_update_time),
            "is_stale": self.is_stale,
            "fresh": self.fresh,
            "detail": self.detail,
            "warnings": list(self.warnings),
        }


def _iso(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=None)
        return dt.isoformat() + "Z"
    return dt.astimezone(tz=None).astimezone().isoformat()


class MarketDataProvider(ABC):
    """Abstract market-data interface.

    Implementations must raise ``NotConfiguredError`` (or return empty frames
    with an explanatory status) rather than fabricate data.
    """

    name: str = "abstract"
    mode: DataMode = DataMode.HISTORICAL

    @abstractmethod
    def get_historical_candles(
        self,
        symbol: str,
        timeframe: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
    ) -> pd.DataFrame:
        ...

    @abstractmethod
    def get_latest_completed_candle(
        self, symbol: str, timeframe: str
    ) -> Optional[pd.Series]:
        ...

    @abstractmethod
    def get_current_quote(self, symbol: str) -> Optional[dict]:
        ...

    @abstractmethod
    def get_data_source_status(self, symbol: Optional[str] = None) -> DataSourceStatus:
        ...


class NotConfiguredError(RuntimeError):
    """Raised when a provider has no authorized/verified data source."""
