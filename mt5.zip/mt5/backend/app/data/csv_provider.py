"""CSV-backed market-data provider (real historical OR synthetic files).

Directory layout::

    <base_dir>/<SYMBOL>_<TIMEFRAME>.csv
    <base_dir>/metadata.json          # optional, labels the dataset

CSV columns (header required)::

    time, open, high, low, close, volume, spread

`time` may be ISO-8601 (recommended, UTC) or a UNIX epoch (seconds).
`volume` and `spread` are optional. Nothing is ever generated here.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Optional

import pandas as pd

from .base import (
    DataMode,
    DataSourceStatus,
    MarketDataProvider,
    empty_frame,
    validate_timeframe,
)
from .validator import detect_stale, validate_candles


def _read_csv(path: str) -> pd.DataFrame:
    header = pd.read_csv(path, nrows=0)
    cols = {c.strip().lower(): c for c in header.columns}
    if "time" in cols:
        time_col = cols["time"]
    elif "timestamp" in cols:
        time_col = cols["timestamp"]
    elif "date" in cols:
        time_col = cols["date"]
    elif "datetime" in cols:
        time_col = cols["datetime"]
    else:
        raise ValueError(
            f"CSV {os.path.basename(path)} has no time/timestamp/date column."
        )

    df = pd.read_csv(path)
    raw = df[time_col]
    # epoch vs ISO detection
    if pd.api.types.is_numeric_dtype(raw):
        # heuristics: ms vs s
        unit = "ms" if raw.dropna().astype("float").median() > 1e11 else "s"
        idx = pd.to_datetime(raw, unit=unit, utc=True)
    else:
        idx = pd.to_datetime(raw, utc=True, format="mixed")

    out = pd.DataFrame(index=pd.DatetimeIndex(idx, name="time"))
    rename = {
        "open": "open", "high": "high", "low": "low", "close": "close",
        "volume": "volume", "tick_volume": "volume", "vol": "volume",
        "spread": "spread",
    }
    for src, dst in rename.items():
        if src in cols and dst not in out.columns:
            out[dst] = pd.to_numeric(df[cols[src]], errors="coerce").values
    for col in ("open", "high", "low", "close"):
        if col not in out.columns:
            raise ValueError(f"CSV {os.path.basename(path)} missing column {col}.")
    if "volume" not in out.columns:
        out["volume"] = pd.NA
    if "spread" not in out.columns:
        out["spread"] = pd.NA
    return out[["open", "high", "low", "close", "volume", "spread"]]


class CsvProvider(MarketDataProvider):
    """Reads candles from CSV files on disk. Never fabricates data."""

    def __init__(
        self,
        base_dir: str,
        mode: DataMode = DataMode.HISTORICAL,
        default_symbol: str = "XAUUSD",
        source_label: Optional[str] = None,
    ) -> None:
        self.base_dir = os.path.abspath(base_dir)
        self.mode = mode
        self.default_symbol = default_symbol
        self.source_label = source_label or f"csv:{os.path.basename(self.base_dir)}"
        self._meta = self._load_meta()

    # ------------------------------------------------------------------ meta
    def _load_meta(self) -> dict:
        path = os.path.join(self.base_dir, "metadata.json")
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    return json.load(fh)
            except (json.JSONDecodeError, OSError):
                return {}
        return {}

    def path_for(self, symbol: str, timeframe: str) -> str:
        tf = validate_timeframe(timeframe)
        return os.path.join(self.base_dir, f"{symbol.upper()}_{tf}.csv")

    def available_symbols(self) -> list[str]:
        if not os.path.isdir(self.base_dir):
            return []
        out = set()
        for fn in os.listdir(self.base_dir):
            if fn.lower().endswith(".csv") and "_" in fn:
                out.add(fn.split("_")[0].upper())
        return sorted(out)

    # -------------------------------------------------------------- interface
    def get_historical_candles(
        self,
        symbol: str,
        timeframe: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
    ) -> pd.DataFrame:
        path = self.path_for(symbol, timeframe)
        if not os.path.isfile(path):
            return empty_frame()
        df = _read_csv(path)
        rep = validate_candles(df, timeframe)
        df = rep.df if rep.df is not None else empty_frame()
        if start is not None:
            start = _as_utc(start)
            df = df[df.index >= start]
        if end is not None:
            end = _as_utc(end)
            df = df[df.index <= end]
        return df

    def get_latest_completed_candle(
        self, symbol: str, timeframe: str
    ) -> Optional[pd.Series]:
        df = self.get_historical_candles(symbol, timeframe)
        if len(df) == 0:
            return None
        return df.iloc[-1]

    def get_current_quote(self, symbol: str) -> Optional[dict]:
        # CSV sources are historical; a quote is derived only from the last
        # stored candle and explicitly flagged as not live.
        df = self.get_historical_candles(symbol, "M5")
        if len(df) == 0:
            return None
        last = df.iloc[-1]
        return {
            "symbol": symbol,
            "bid": None,
            "ask": None,
            "mid": float(last["close"]),
            "spread": None,
            "time": df.index[-1].to_pydatetime().isoformat(),
            "live": False,
        }

    def get_data_source_status(
        self, symbol: Optional[str] = None
    ) -> DataSourceStatus:
        symbol = (symbol or self.default_symbol).upper()
        warnings: list[str] = []
        if not os.path.isdir(self.base_dir):
            return DataSourceStatus(
                provider=self.source_label,
                mode=self.mode,
                available=False,
                symbol=symbol,
                detail=f"Directory not found: {self.base_dir}",
            )
        df = self.get_historical_candles(symbol, "M5")
        available = len(df) > 0
        last = df.index[-1].to_pydatetime() if available else None
        stale = detect_stale(df, "M5") if available else True
        if self.mode == DataMode.SYNTHETIC:
            warnings.append("Synthetic test data - not real market prices.")
        meta_dataset = self._meta.get("dataset")
        if meta_dataset:
            warnings.append(f"dataset={meta_dataset}")
        return DataSourceStatus(
            provider=self.source_label,
            mode=self.mode,
            available=available,
            symbol=symbol,
            last_candle_time=last,
            last_update_time=last,
            is_stale=stale,
            fresh=available and not stale,
            detail=(
                f"{len(df)} M5 candles loaded from {os.path.basename(self.base_dir)}"
                if available else "No candles found for symbol/timeframe."
            ),
            warnings=warnings,
        )


def _as_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)
