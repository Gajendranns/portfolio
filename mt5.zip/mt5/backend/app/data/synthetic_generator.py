"""Synthetic XAUUSD sample-data generator for TESTING ONLY.

This module is deliberately isolated from real-data providers. It only runs
when its CLI is invoked explicitly. Every artifact is labeled
SYNTHETIC_TEST_DATA and is never presented as real market data.

The artificial price regimes below (uptrend, downtrend, sideways, high/low
volatility) are testing scenarios, not predictions of actual gold prices.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional

import numpy as np
import pandas as pd

from .base import TIMEFRAME_MINUTES, CANDLE_COLUMNS
from .validator import validate_candles

SYNTHETIC_LABEL = "SYNTHETIC_TEST_DATA"

REGIMES = {
    "uptrend": {"drift": 0.00020, "vol": 0.00080},
    "downtrend": {"drift": -0.00020, "vol": 0.00080},
    "sideways": {"drift": 0.0, "vol": 0.00040},
    "high_volatility": {"drift": 0.0, "vol": 0.00200},
    "low_volatility": {"drift": 0.0, "vol": 0.00020},
}
REGIME_CYCLE = ["uptrend", "downtrend", "sideways", "high_volatility",
                "low_volatility", "sideways", "uptrend", "downtrend"]


def build_regime_plan(n_bars: int, rng: np.random.Generator) -> list[str]:
    plan: list[str] = []
    i = 0
    while i < n_bars:
        regime = REGIME_CYCLE[rng.integers(0, len(REGIME_CYCLE))]
        length = int(rng.integers(36, 144))  # 3 to 12 hours of M5 bars
        plan.extend([regime] * min(length, n_bars - i))
        i += length
    return plan[:n_bars]


def generate_m5(
    *,
    start: datetime,
    end: datetime,
    initial_price: float,
    seed: int,
    spread_points: float = 20.0,
    volume: bool = True,
) -> pd.DataFrame:
    """Generate an M5 OHLC(+spread/volume) frame with an artificial path."""
    start = _utc(start)
    end = _utc(end)
    idx = pd.date_range(start=start, end=end, freq="5min", tz="UTC", inclusive="left")
    n = len(idx)
    if n == 0:
        raise ValueError("start/end contained no M5 slots.")

    rng = np.random.default_rng(seed)
    plan = build_regime_plan(n, rng)

    prices = np.empty(n)
    price = initial_price
    for i in range(n):
        reg = REGIMES[plan[i]]
        ret = reg["drift"] + reg["vol"] * rng.normal()
        price = price * np.exp(ret)
        if price <= 0:
            price = initial_price * 0.5
        prices[i] = price

    prev = initial_price
    rows = []
    for i in range(n):
        o = prev
        c = float(prices[i])
        reg = REGIMES[plan[i]]
        wick = reg["vol"] * (1.0 + rng.random())
        hi = max(o, c) * (1.0 + wick)
        lo = min(o, c) * (1.0 - wick * 0.8)
        sp = round(spread_points * (0.75 + rng.random() * 0.5), 2)
        rows.append({
            "open": round(o, 2),
            "high": round(hi, 2),
            "low": round(lo, 2),
            "close": round(c, 2),
            "volume": int(rng.integers(5, 60)) if volume else np.nan,
            "spread": sp * 0.01 if spread_points else np.nan,
        })
        prev = c

    df = pd.DataFrame(rows, index=pd.DatetimeIndex(idx, name="time"))
    df = df.astype({"open": float, "high": float, "low": float, "close": float})
    return df[CANDLE_COLUMNS]


def aggregate_from_m5(m5: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    """Aggregate completed contiguous M5 groups into M15/H1 candles.

    Only groups whose M5 members form a contiguous 5-minute sequence inside the
    bucket are treated as completed. A trailing incomplete group (e.g. fewer
    than 3 M5 bars for M15) is dropped.
    """
    tf = timeframe.strip().upper()
    if tf not in ("M15", "H1"):
        raise ValueError("Only M15 and H1 are aggregatable here.")
    step = pd.Timedelta(minutes=TIMEFRAME_MINUTES[tf])
    m5_step = pd.Timedelta(minutes=5)
    n_per = int(TIMEFRAME_MINUTES[tf] // 5)

    seq = list(m5.index)
    rows = []
    i = 0
    while i < len(seq):
        group_start = seq[i]
        # collect contiguous M5 slots with strict 5-min spacing
        j = i
        while (
            j < len(seq)
            and seq[j] < group_start + step
            and (j == i or seq[j] - seq[j - 1] == m5_step)
        ):
            j += 1
        count = j - i
        if count != n_per:
            # incomplete group at the end (or discontinuity) -> drop
            break
        chunk = m5.iloc[i:j]
        rows.append({
            "open": float(chunk["open"].iloc[0]),
            "high": float(chunk["high"].max()),
            "low": float(chunk["low"].min()),
            "close": float(chunk["close"].iloc[-1]),
            "volume": float(chunk["volume"].sum())
            if chunk["volume"].notna().any() else np.nan,
            "spread": float(chunk["spread"].mean())
            if chunk["spread"].notna().any() else np.nan,
        })
        i = j

    out = pd.DataFrame(rows, columns=CANDLE_COLUMNS)
    starts = [seq[0]] + [None] * (len(rows) - 1)
    # recompute start times: every group begins at the first M5 slot of the bucket
    idx = []
    k = 0
    while k < len(seq):
        gs = seq[k]
        j = k
        while (
            j < len(seq)
            and seq[j] < gs + step
            and (j == k or seq[j] - seq[j - 1] == m5_step)
        ):
            j += 1
        if j - k != n_per:
            break
        idx.append(gs)
        k = j
    out.index = pd.DatetimeIndex(idx, name="time", tz=m5.index.tz)
    return out[CANDLE_COLUMNS]


def write_dataset(
    *,
    start: datetime,
    end: datetime,
    initial_price: float,
    seed: int,
    output_dir: str,
    symbol: str = "XAUUSD",
    spread_points: float = 20.0,
    volume: bool = True,
    force: bool = False,
) -> dict:
    """Generate M5 then aggregate M15/H1, write CSV + metadata. Returns summary."""
    os.makedirs(output_dir, exist_ok=True)
    targets = {
        "M5": os.path.join(output_dir, f"{symbol}_M5.csv"),
        "M15": os.path.join(output_dir, f"{symbol}_M15.csv"),
        "H1": os.path.join(output_dir, f"{symbol}_H1.csv"),
    }
    existing = [p for p in targets.values() if os.path.exists(p)]
    if existing and not force:
        raise RuntimeError(
            "Refusing to overwrite existing file(s) that may be real data: "
            + ", ".join(existing)
            + ". Use --force only if you are certain they are synthetic."
        )

    m5 = generate_m5(
        start=start, end=end, initial_price=initial_price, seed=seed,
        spread_points=spread_points, volume=volume,
    )
    m15 = aggregate_from_m5(m5, "M15")
    h1 = aggregate_from_m5(m5, "H1")

    # validation
    for name, df in (("M5", m5), ("M15", m15), ("H1", h1)):
        rep = validate_candles(df, name)
        if not rep.is_valid:
            raise RuntimeError(f"Generated {name} is invalid: {rep.errors}")
        if rep.n_duplicates or rep.n_invalid_ohlc:
            raise RuntimeError(f"Generated {name} failed validation.")

    meta = {
        "dataset": SYNTHETIC_LABEL,
        "symbol": symbol,
        "seed": seed,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "initial_price": initial_price,
        "spread_points": spread_points,
        "volume": bool(volume),
        "timeframes": {name: len(df) for name, df in
                       (("M5", m5), ("M15", m15), ("H1", h1))},
        "note": "SYNTHETIC TEST DATA - NOT REAL MARKET PRICES. "
                "Used for testing only; never for trading decisions.",
    }
    for name, df in (("M5", m5), ("M15", m15), ("H1", h1)):
        df.to_csv(targets[name])
    with open(os.path.join(output_dir, "metadata.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2)
    return {
        "files": targets,
        "row_counts": meta["timeframes"],
        "metadata": os.path.join(output_dir, "metadata.json"),
        "seed": seed,
    }


def _utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description=(
        "Generate SYNTHETIC_TEST_DATA XAUUSD M5/M15/H1 candles for testing "
        "only. NEVER used for trading decisions."
    ))
    p.add_argument("--days", type=int, default=30, help="Number of calendar days")
    p.add_argument("--seed", type=int, default=42, help="Random seed (default 42)")
    p.add_argument("--symbol", default="XAUUSD")
    p.add_argument("--initial-price", type=float, default=2300.0)
    p.add_argument("--output-dir", default="../../../data/synthetic")
    p.add_argument("--start", default=None, help="ISO start (default: now - days)")
    p.add_argument("--spread-points", type=float, default=20.0)
    p.add_argument("--force", action="store_true",
                   help="Overwrite existing files (only if you are sure they "
                        "are synthetic).")
    args = p.parse_args(argv)

    end = datetime.now(timezone.utc)
    if args.start:
        start = _utc(datetime.fromisoformat(args.start))
    else:
        start = end - timedelta(days=args.days)
    # align to a 5-minute boundary
    start = start.replace(second=0, microsecond=0)
    while start.minute % 5:
        start += timedelta(minutes=1)

    out = os.path.abspath(os.path.join(os.path.dirname(__file__), args.output_dir))
    try:
        summary = write_dataset(
            start=start, end=end, initial_price=args.initial_price,
            seed=args.seed, output_dir=out, symbol=args.symbol,
            spread_points=args.spread_points, force=args.force,
        )
    except RuntimeError as exc:
        print(f"ERROR: {exc}")
        return 1

    print(f"SYNTHETIC_TEST_DATA generated with seed={summary['seed']}")
    for name, path in summary["files"].items():
        print(f"  {name:>3} -> {path}  ({summary['row_counts'][name]} rows)")
    print(f"  metadata -> {summary['metadata']}")
    print("WARNING: artificial testing data only. Not real market prices.")
    return 0


if __name__ == "__main__":
    sys.exit(main())