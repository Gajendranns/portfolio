"""Authorized live broker/provider adapter.

This module intentionally ships **disabled and unimplemented**.

There is no public VT Markets retail market-data REST API, and the MT5 Web
Terminal exposes no supported programmatic data interface. The MetaTrader5
Python package only connects to a locally running MT5 *desktop* terminal and
must NOT be presented as a Web Terminal connection.

To go LIVE you must plug in a real, authorized source. Implement one of:

  1. Export CSVs from MT5 desktop (or request them from VT Markets) and load
     them through ``CsvProvider`` labelled HISTORICAL.
  2. Use an authorized market-data provider with a documented API and your
     own key, and implement ``fetch_*`` below against that documented API.
  3. Use Dukascopy's published historical download for XAUUSD (historical).

Until then this provider reports ``available=False`` and raises
``NotConfiguredError`` for any data request. It never fabricates prices and is
never silently substituted for SYNTHETIC or HISTORICAL data.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

import pandas as pd

from .base import (
    DataMode,
    DataSourceStatus,
    MarketDataProvider,
    NotConfiguredError,
    empty_frame,
)


class BrokerProvider(MarketDataProvider):
    name = "broker"
    mode = DataMode.LIVE

    def __init__(
        self,
        provider: str = "",
        base_url: str = "",
        api_key: str = "",
        symbol: str = "XAUUSD",
    ) -> None:
        self.provider = provider
        self.base_url = base_url
        self.api_key = api_key
        self.default_symbol = symbol

    @property
    def configured(self) -> bool:
        return bool(self.provider and self.base_url)

    # ------------------------------------------------------------ data stubs
    def get_historical_candles(
        self,
        symbol: str,
        timeframe: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
    ) -> pd.DataFrame:
        if not self.configured:
            raise NotConfiguredError(
                "No authorized live data source configured. Set LIVE_PROVIDER "
                "and LIVE_API_BASE_URL, then implement an authorized adapter."
            )
        # Deliberately not implemented: we do not invent provider endpoints.
        raise NotConfiguredError(
            f"Live adapter for provider={self.provider!r} is not implemented. "
            "Implement it against the provider's official documented API."
        )

    def get_latest_completed_candle(
        self, symbol: str, timeframe: str
    ) -> Optional[pd.Series]:
        df = self.get_historical_candles(symbol, timeframe)
        return df.iloc[-1] if len(df) else None

    def get_current_quote(self, symbol: str) -> Optional[dict]:
        return None

    def get_data_source_status(
        self, symbol: Optional[str] = None
    ) -> DataSourceStatus:
        symbol = (symbol or self.default_symbol).upper()
        if not self.configured:
            return DataSourceStatus(
                provider="broker:unconfigured",
                mode=DataMode.LIVE,
                available=False,
                symbol=symbol,
                detail=(
                    "LIVE mode is disabled until an authorized data source is "
                    "configured and verified. No live prices are available."
                ),
                warnings=[
                    "Do not treat backtests or synthetic results as live data."
                ],
            )
        return DataSourceStatus(
            provider=f"broker:{self.provider}",
            mode=DataMode.LIVE,
            available=False,
            symbol=symbol,
            detail=(
                "Provider configured but no verified adapter implemented. "
                "LIVE mode remains unavailable."
            ),
        )
