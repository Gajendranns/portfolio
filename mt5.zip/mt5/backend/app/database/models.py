"""SQLite schema (DDL). Kept explicit and dependency-free (stdlib sqlite3)."""
SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    signal TEXT NOT NULL,
    signal_timestamp TEXT NOT NULL,
    data_timestamp TEXT,
    data_source TEXT,
    data_mode TEXT,
    entry REAL,
    stop_loss REAL,
    take_profit REAL,
    risk_reward REAL,
    confidence REAL,
    h1_trend TEXT,
    m15_bias TEXT,
    payload TEXT
);

CREATE TABLE IF NOT EXISTS backtest_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_at TEXT NOT NULL,
    symbol TEXT,
    data_source TEXT,
    from_time TEXT,
    to_time TEXT,
    config TEXT,
    summary TEXT
);

CREATE TABLE IF NOT EXISTS backtest_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER,
    symbol TEXT,
    side TEXT,
    entry_time TEXT,
    exit_time TEXT,
    entry_price REAL,
    exit_price REAL,
    side_signal TEXT,
    pnl REAL,
    pnl_after_costs REAL,
    status TEXT
);
"""