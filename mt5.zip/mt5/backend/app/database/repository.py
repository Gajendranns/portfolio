"""SQLite repository: signals + backtest persistence."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from typing import Generator, List, Optional

from .models import SCHEMA


class Repository:
    def __init__(self, database_url: str = "sqlite:///./signal_bot.db") -> None:
        if database_url.startswith("sqlite:///"):
            path = database_url[len("sqlite:///"):]
        else:
            path = database_url
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    @contextmanager
    def tx(self) -> Generator[sqlite3.Connection, None, None]:
        try:
            yield self._conn
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    # ------------------------------------------------------------------ signals
    def insert_signal(self, sig: dict) -> int:
        with self.tx() as c:
            cur = c.execute(
                """INSERT INTO signals
                   (symbol, signal, signal_timestamp, data_timestamp,
                    data_source, data_mode, entry, stop_loss, take_profit,
                    risk_reward, confidence, h1_trend, m15_bias, payload)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    sig.get("symbol"), sig.get("signal"),
                    sig.get("signal_timestamp"), sig.get("data_timestamp"),
                    sig.get("data_source"), sig.get("data_mode"),
                    sig.get("entry"), sig.get("stop_loss"),
                    sig.get("take_profit"), sig.get("risk_reward"),
                    sig.get("confidence"),
                    json.dumps(sig.get("h1_trend")),
                    json.dumps(sig.get("m15_bias")),
                    json.dumps(sig),
                ),
            )
            return int(cur.lastrowid)

    def list_signals(self, limit: int = 50) -> List[dict]:
        with self.tx() as c:
            rows = c.execute(
                "SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if d.get("payload"):
                try:
                    d = json.loads(d["payload"])
                except (TypeError, json.JSONDecodeError):
                    pass
            out.append(d)
        return out

    # ---------------------------------------------------------------- backtests
    def insert_backtest_run(self, *, symbol, data_source, from_time, to_time,
                            config: dict, summary: dict) -> int:
        with self.tx() as c:
            cur = c.execute(
                """INSERT INTO backtest_runs
                   (run_at, symbol, data_source, from_time, to_time, config, summary)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    summary.get("run_at", ""), symbol, data_source,
                    from_time, to_time, json.dumps(config),
                    json.dumps(summary),
                ),
            )
            run_id = int(cur.lastrowid)
        return run_id

    def insert_backtest_trades(self, run_id: int, trades: List[dict]) -> None:
        with self.tx() as c:
            c.executemany(
                """INSERT INTO backtest_trades
                   (run_id, symbol, side, entry_time, exit_time, entry_price,
                    exit_price, side_signal, pnl, pnl_after_costs, status)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                [
                    (
                        run_id, t.get("symbol"), t.get("side"),
                        t.get("entry_time"), t.get("exit_time"),
                        t.get("entry_price"), t.get("exit_price"),
                        t.get("side_signal"), t.get("pnl"),
                        t.get("pnl_after_costs"), t.get("status"),
                    )
                    for t in trades
                ],
            )

    def list_backtest_runs(self, limit: int = 20) -> List[dict]:
        with self.tx() as c:
            rows = c.execute(
                "SELECT * FROM backtest_runs ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            for k in ("config", "summary"):
                try:
                    d[k] = json.loads(d[k] or "{}")
                except (TypeError, json.JSONDecodeError):
                    d[k] = {}
            out.append(d)
        return out

    def get_backtest_trades(self, run_id: int) -> List[dict]:
        with self.tx() as c:
            rows = c.execute(
                "SELECT * FROM backtest_trades WHERE run_id=? ORDER BY id",
                (run_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    def close(self) -> None:
        try:
            self._conn.close()
        except sqlite3.Error:
            pass