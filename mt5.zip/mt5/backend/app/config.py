"""Central configuration.

All strategy thresholds are configurable via environment variables / .env.
Nothing here should be read as a promise of profitability.
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=os.path.join(os.path.dirname(__file__), "..", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- data mode ---
    data_mode: str = Field(default="HISTORICAL")

    # --- instrument ---
    symbol: str = Field(default="XAUUSD")
    symbol_aliases: str = Field(default="XAUUSD,GOLD,XAUUSD.a,XAUUSDm")

    # --- paths (defaults resolve to the repository's data/ directory) ---
    data_dir: str = Field(default=str(PROJECT_ROOT / "data"))
    historical_dir: str = Field(default=str(PROJECT_ROOT / "data" / "historical"))
    synthetic_dir: str = Field(default=str(PROJECT_ROOT / "data" / "synthetic"))

    # --- database ---
    database_url: str = Field(default="sqlite:///./signal_bot.db")

    # --- cors ---
    cors_origins: str = Field(
        default="http://localhost:5173,http://127.0.0.1:5173"
    )

    # --- live provider (disabled until configured + verified) ---
    live_provider: str = Field(default="")
    live_api_base_url: str = Field(default="")
    live_api_key: str = Field(default="")

    # --- indicators ---
    ema_fast: int = 20
    ema_mid: int = 50
    ema_slow: int = 200
    rsi_period: int = 14
    atr_period: int = 14

    # --- filters ---
    max_spread_points: float = 35.0
    min_atr_points: float = 15.0
    max_atr_points: float = 1000.0
    swing_lookback: int = 5
    m5_confirm_threshold: int = 2

    # --- risk ---
    reward_risk: float = 2.0
    atr_stop_multiplier: float = 1.5
    risk_percent: float = 0.5
    max_daily_loss_percent: float = 3.0
    max_consecutive_losses: int = 4
    signal_expiry_minutes: int = 30

    # --- strategy directional thresholds ---
    rsi_long_min: float = 50.0
    rsi_short_max: float = 50.0

    @field_validator("data_mode")
    @classmethod
    def _valid_mode(cls, v: str) -> str:
        v = v.strip().upper()
        if v not in {"SYNTHETIC", "HISTORICAL", "LIVE"}:
            raise ValueError("DATA_MODE must be SYNTHETIC, HISTORICAL or LIVE")
        return v

    @property
    def symbol_list(self) -> List[str]:
        base = [self.symbol] + [
            s.strip() for s in self.symbol_aliases.split(",") if s.strip()
        ]
        seen, out = set(), []
        for s in base:
            if s not in seen:
                seen.add(s)
                out.append(s)
        return out

    @property
    def cors_origin_list(self) -> List[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def live_enabled(self) -> bool:
        return bool(self.live_provider and self.live_api_base_url)


@lru_cache
def get_settings() -> Settings:
    return Settings()
