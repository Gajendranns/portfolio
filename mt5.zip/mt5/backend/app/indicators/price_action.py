"""Price-action helpers.

Candlestick patterns are context-dependent signals, NOT guarantees. Every
function here is a heuristic used as one input among several.
"""
from __future__ import annotations

from typing import List, Optional

import pandas as pd


def swing_points(df: pd.DataFrame, lookback: int = 5) -> pd.DataFrame:
    """Mark swing highs/lows.

    A swing high at i requires high[i] to be the strict maximum of the
    ``lookback`` bars on both sides (i.e. the pattern is only confirmed
    ``lookback`` bars later - no look-ahead when used causally).
    """
    n = len(df)
    sh = [False] * n
    sl = [False] * n
    highs = df["high"].to_numpy()
    lows = df["low"].to_numpy()
    for i in range(lookback, n - lookback):
        win_h = highs[i - lookback : i + lookback + 1]
        win_l = lows[i - lookback : i + lookback + 1]
        if highs[i] == win_h.max() and (win_h == highs[i]).sum() == 1:
            sh[i] = True
        if lows[i] == win_l.min() and (win_l == lows[i]).sum() == 1:
            sl[i] = True
    out = df.copy()
    out["swing_high"] = sh
    out["swing_low"] = sl
    return out


def last_swing_levels(
    df: pd.DataFrame, lookback: int = 5
) -> tuple[Optional[float], Optional[float]]:
    """Most recent confirmed swing high and swing low (or None)."""
    marked = swing_points(df, lookback)
    sh = marked[marked["swing_high"]]
    sl = marked[marked["swing_low"]]
    high = float(sh["high"].iloc[-1]) if len(sh) else None
    low = float(sl["low"].iloc[-1]) if len(sl) else None
    return high, low


def is_bullish_engulfing(df: pd.DataFrame, i: int) -> bool:
    if i < 1:
        return False
    o, c = df["open"].iloc[i], df["close"].iloc[i]
    po, pc = df["open"].iloc[i - 1], df["close"].iloc[i - 1]
    prev_bear = pc < po
    curr_bull = c > o
    return prev_bear and curr_bull and c >= po and o <= pc


def is_bearish_engulfing(df: pd.DataFrame, i: int) -> bool:
    if i < 1:
        return False
    o, c = df["open"].iloc[i], df["close"].iloc[i]
    po, pc = df["open"].iloc[i - 1], df["close"].iloc[i - 1]
    prev_bull = pc > po
    curr_bear = c < o
    return prev_bull and curr_bear and c <= po and o >= pc


def is_bullish_rejection(df: pd.DataFrame, i: int, wick_ratio: float = 2.0) -> bool:
    """Long lower wick relative to body (hammer-like)."""
    o, c, h, l = (
        df["open"].iloc[i], df["close"].iloc[i],
        df["high"].iloc[i], df["low"].iloc[i],
    )
    body = abs(c - o)
    rng = h - l
    if rng <= 0:
        return False
    lower_wick = min(o, c) - l
    return lower_wick >= wick_ratio * max(body, 1e-9) and lower_wick / rng >= 0.5


def is_bearish_rejection(df: pd.DataFrame, i: int, wick_ratio: float = 2.0) -> bool:
    """Long upper wick relative to body (shooting-star-like)."""
    o, c, h, l = (
        df["open"].iloc[i], df["close"].iloc[i],
        df["high"].iloc[i], df["low"].iloc[i],
    )
    body = abs(c - o)
    rng = h - l
    if rng <= 0:
        return False
    upper_wick = h - max(o, c)
    return upper_wick >= wick_ratio * max(body, 1e-9) and upper_wick / rng >= 0.5


def find_breakout_retest(
    df: pd.DataFrame,
    level: float,
    direction: str,
    lookback: int = 20,
    tolerance_atr: float = 0.5,
) -> bool:
    """True if price broke ``level`` then retested it, in ``direction``.

    Requires an ATR column. Bullish: a prior close below the level, a close
    above it, then a pullback that touched the level from above.
    """
    if "atr" not in df or len(df) < 3:
        return False
    window = df.iloc[-lookback:] if len(df) > lookback else df
    atr_val = window["atr"].iloc[-1]
    if pd.isna(atr_val) or atr_val <= 0:
        return False
    tol = atr_val * tolerance_atr
    closes = window["close"]
    if direction == "bullish":
        broke = (closes < level).any() and (closes > level).any()
        touched = (window["low"] <= level + tol).any()
        return bool(broke and touched)
    if direction == "bearish":
        broke = (closes > level).any() and (closes < level).any()
        touched = (window["high"] >= level - tol).any()
        return bool(broke and touched)
    return False


def support_resistance(
    df: pd.DataFrame, lookback: int = 5, max_levels: int = 4
) -> dict:
    """Cluster recent swing points into support and resistance levels."""
    marked = swing_points(df, lookback)
    highs = sorted(
        marked[marked["swing_high"]]["high"].tolist(), reverse=True
    )
    lows = sorted(marked[marked["swing_low"]]["low"].tolist())
    return {
        "resistance": [float(x) for x in highs[:max_levels]],
        "support": [float(x) for x in lows[:max_levels]],
    }
