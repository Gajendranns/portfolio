"""Central Pivot Range (CPR) and daily aggregation.

CPR is calculated from the *previous completed daily candle*:

    pivot (P) = (H + L + C) / 3
    BC        = (H + L) / 2
    TC        = 2*P - BC

Timezone: candles are stored in UTC. Broker trading days may start at a
different local hour, so ``daily_candles`` accepts ``server_offset_hours``
(shift applied before grouping) and ``boundary_hour``. The chosen convention
is returned so it is never assumed silently.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pandas as pd


@dataclass
class CPR:
    pivot: float
    bc: float
    tc: float

    @property
    def top(self) -> float:
        return max(self.bc, self.tc)

    @property
    def bottom(self) -> float:
        return min(self.bc, self.tc)

    @property
    def width(self) -> float:
        return self.top - self.bottom

    def to_dict(self) -> dict:
        return {
            "pivot": round(self.pivot, 5),
            "bc": round(self.bc, 5),
            "tc": round(self.tc, 5),
            "top": round(self.top, 5),
            "bottom": round(self.bottom, 5),
            "width": round(self.width, 5),
        }


def compute_cpr(prev_high: float, prev_low: float, prev_close: float) -> CPR:
    pivot = (prev_high + prev_low + prev_close) / 3.0
    bc = (prev_high + prev_low) / 2.0
    tc = 2.0 * pivot - bc
    return CPR(pivot=pivot, bc=bc, tc=tc)


def daily_candles(
    df: pd.DataFrame,
    *,
    server_offset_hours: int = 0,
    boundary_hour: int = 0,
) -> pd.DataFrame:
    """Aggregate intraday candles into UTC-day candles (documented convention).

    ``server_offset_hours`` shifts timestamps into broker-server time before
    grouping; ``boundary_hour`` sets the server-time hour that starts a day.
    """
    if df is None or len(df) == 0:
        return df
    shift = pd.Timedelta(hours=server_offset_hours + boundary_hour)
    local = df.copy()
    local.index = local.index + shift
    grouped = local.groupby(local.index.normalize()).agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        volume=("volume", "sum"),
    )
    grouped.index.name = "time"
    # convert day label back to UTC start
    day_idx = pd.DatetimeIndex(grouped.index)
    if day_idx.tz is None:
        day_idx = day_idx.tz_localize("UTC")
    else:
        day_idx = day_idx.tz_convert("UTC")
    grouped.index = day_idx - shift
    return grouped


def previous_day_cpr(
    intraday: pd.DataFrame,
    *,
    server_offset_hours: int = 0,
    boundary_hour: int = 0,
) -> Optional[CPR]:
    """CPR from the last *completed* daily candle in ``intraday``."""
    daily = daily_candles(
        intraday, server_offset_hours=server_offset_hours, boundary_hour=boundary_hour
    )
    if daily is None or len(daily) < 1:
        return None
    prev = daily.iloc[-1]
    return compute_cpr(
        float(prev["high"]), float(prev["low"]), float(prev["close"])
    )


def cpr_position(price: float, cpr: CPR) -> str:
    if price > cpr.top:
        return "above"
    if price < cpr.bottom:
        return "below"
    return "inside"
