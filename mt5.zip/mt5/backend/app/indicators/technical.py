"""Classical technical indicators on a validated candle DataFrame.

All functions take/return pandas objects indexed by candle time (UTC) and never
look ahead: the value at row i uses only rows <= i.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def ema(series: pd.Series, period: int) -> pd.Series:
    """Exponential moving average (recursive, adjust=False)."""
    return series.ewm(span=period, adjust=False).mean()


def sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Wilder's RSI (no-loss => 100, flat => 50, warmup => NaN)."""
    delta = series.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    no_loss = (avg_loss == 0).to_numpy()
    no_gain = (avg_gain == 0).to_numpy()
    rs = np.where(no_loss, np.nan, (avg_gain / avg_loss).to_numpy())
    out = 100.0 - (100.0 / (1.0 + rs))
    out = np.where(no_loss, 100.0, out)
    out = np.where(no_loss & no_gain, 50.0, out)
    return pd.Series(out, index=series.index)


def macd(
    series: pd.Series,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> pd.DataFrame:
    """MACD line, signal line and histogram."""
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    hist = macd_line - signal_line
    return pd.DataFrame(
        {"macd": macd_line, "signal": signal_line, "hist": hist}
    )


def true_range(df: pd.DataFrame) -> pd.Series:
    prev_close = df["close"].shift(1)
    a = df["high"] - df["low"]
    b = (df["high"] - prev_close).abs()
    c = (df["low"] - prev_close).abs()
    tr = pd.concat([a, b, c], axis=1).max(axis=1)
    return tr


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Wilder's Average True Range."""
    tr = true_range(df)
    return tr.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()


def add_core_indicators(
    df: pd.DataFrame,
    *,
    ema_fast: int = 20,
    ema_mid: int = 50,
    ema_slow: int = 200,
    rsi_period: int = 14,
    atr_period: int = 14,
) -> pd.DataFrame:
    """Return a copy of ``df`` with standard indicator columns attached."""
    out = df.copy()
    out["ema_fast"] = ema(out["close"], ema_fast)
    out["ema_mid"] = ema(out["close"], ema_mid)
    out["ema_slow"] = ema(out["close"], ema_slow)
    out["rsi"] = rsi(out["close"], rsi_period)
    m = macd(out["close"])
    out["macd"] = m["macd"]
    out["macd_signal"] = m["signal"]
    out["macd_hist"] = m["hist"]
    out["atr"] = atr(out, atr_period)
    return out
