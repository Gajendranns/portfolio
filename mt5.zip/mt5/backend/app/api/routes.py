"""FastAPI routes. Validates inputs, returns consistent JSON.

Never exposes secrets. No public deployment: local CORS only.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from ..backtest.engine import BacktestConfig, run_backtest
from ..config import Settings, get_settings
from ..database.repository import Repository
from ..data.base import TIMEFRAME_MINUTES
from ..services.market_service import MarketService
from ..services.signal_service import SignalService

router = APIRouter(prefix="/api")
CHART_LIMIT = 500


def candle_payload(df, symbol: str, timeframe: str, limit: int = CHART_LIMIT) -> list:
    if df is None or len(df) == 0:
        return []
    df = df.iloc[-limit:]
    out = []
    for t, row in df.iterrows():
        out.append({
            "time": t.isoformat(),
            "symbol": symbol,
            "timeframe": timeframe,
            "open": round(float(row["open"]), 5),
            "high": round(float(row["high"]), 5),
            "low": round(float(row["low"]), 5),
            "close": round(float(row["close"]), 5),
            "volume": None if row["volume"] is None or (row["volume"] != row["volume"])
            else float(row["volume"]),
            "spread": None if row["spread"] is None or (row["spread"] != row["spread"])
            else float(row["spread"]),
        })
    return out


class BacktestRequest(BaseModel):
    symbol: Optional[str] = None
    spread_points: Optional[float] = None
    slippage_points: Optional[float] = None
    commission_price_points: Optional[float] = None
    max_hold_bars: Optional[int] = None
    from_time: Optional[str] = None
    to_time: Optional[str] = None
    with_trades: bool = False

    def to_config(self) -> BacktestConfig:
        return BacktestConfig(
            spread_points=float(self.spread_points or 20.0),
            slippage_points=float(self.slippage_points or 5.0),
            commission_price_points=float(self.commission_price_points or 0.0),
            max_hold_bars=int(self.max_hold_bars or 48),
            symbol=str(self.symbol or "XAUUSD"),
        )


def _parse_dt(value: Optional[str]) -> Optional[datetime]:
    if value is None:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"Invalid datetime: {value}") from exc


@router.get("/health")
def health() -> dict:
    return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}


@router.get("/data/status")
def data_status(
    symbol: Optional[str] = None,
    settings: Settings = Depends(get_settings),
) -> dict:
    mkt = MarketService(settings)
    st = mkt.get_data_status(symbol or settings.symbol)
    out = st.to_dict()
    out["symbols"] = mkt.provider.symbol_list if hasattr(mkt.provider, "symbol_list") else settings.symbol_list
    return out


@router.get("/market/{symbol}")
def market(
    symbol: str,
    timeframe: Optional[str] = Query(default=None),
    limit: int = Query(default=CHART_LIMIT, le=2000),
    settings: Settings = Depends(get_settings),
) -> dict:
    symbol = symbol.upper()
    if symbol not in settings.symbol_list:
        raise HTTPException(status_code=404, detail=f"Symbol not allowed: {symbol}")
    mkt = MarketService(settings)
    snap = mkt.get_full_snapshot(symbol)
    candles = {}
    for tf, df in snap["frames"].items():
        candles[tf] = candle_payload(df, symbol, tf, limit)
    st = mkt.get_data_status(symbol)
    return {
        "symbol": symbol,
        "mode": st.mode.value,
        "data_mode": st.mode.value,
        "data_source": st.provider,
        "status": st.to_dict(),
        "candles": candles,
        "cpr": snap["cpr"],
        "quote": snap["quote"],
        "reports": snap["reports"],
        "meta": snap["meta"],
        "synthetic_warning": (
            "SYNTHETIC TEST DATA - NOT REAL MARKET PRICES"
            if st.mode.value == "SYNTHETIC" else None
        ),
    }


@router.get("/signals/latest")
def signals_latest(
    symbol: Optional[str] = None,
    settings: Settings = Depends(get_settings),
) -> dict:
    mkt = MarketService(settings)
    repo = _repo(settings)
    svc = SignalService(settings, mkt, repo)
    sig = svc.latest_signal(symbol)
    return {"latest": sig.to_dict()}


@router.get("/signals/history")
def signals_history(
    limit: int = Query(default=50, le=200),
    settings: Settings = Depends(get_settings),
) -> dict:
    return {"history": _repo(settings).list_signals(limit=limit)}


@router.post("/backtest/run")
def backtest_run(
    req: BacktestRequest,
    settings: Settings = Depends(get_settings),
) -> dict:
    mkt = MarketService(settings)
    repo = _repo(settings)
    symbol = (req.symbol or settings.symbol).upper()
    if symbol not in settings.symbol_list:
        raise HTTPException(status_code=404, detail=f"Symbol not allowed: {symbol}")
    snap = mkt.get_full_snapshot(symbol)
    st = mkt.get_data_status(symbol)
    cfg = req.to_config()
    cfg.symbol = symbol
    start = _parse_dt(req.from_time)
    end = _parse_dt(req.to_time)
    result = run_backtest(
        m5=snap["frames"]["M5"],
        m15=snap["frames"]["M15"],
        h1=snap["frames"]["H1"],
        settings=settings,
        cfg=cfg,
        data_mode=st.mode.value,
        data_source=st.provider,
        start=start,
        end=end,
    )
    # persist
    try:
        run_id = repo.insert_backtest_run(
            symbol=symbol,
            data_source=st.provider,
            from_time=result.from_time,
            to_time=result.to_time,
            config=result.cfg,
            summary={**result.metrics.to_dict(), "run_at": datetime.now(timezone.utc).isoformat()},
        )
        repo.insert_backtest_trades(run_id, [t.to_dict() for t in result.trades])
    except Exception:
        run_id = None
    out = result.to_dict(with_trades=req.with_trades)
    out["run_id"] = run_id
    out["synthetic_warning"] = (
        "SYNTHETIC TEST DATA - results are artificial and imply nothing about "
        "real market performance." if st.mode.value == "SYNTHETIC" else None
    )
    return out


@router.get("/backtest/summary")
def backtest_summary(
    run_id: Optional[int] = Query(default=None),
    settings: Settings = Depends(get_settings),
) -> dict:
    repo = _repo(settings)
    runs = repo.list_backtest_runs(limit=20)
    if run_id is not None:
        runs = [r for r in runs if r["id"] == run_id]
        if not runs:
            raise HTTPException(status_code=404, detail="backtest run not found")
        run = runs[0]
        return {"run": run, "trades": repo.get_backtest_trades(run_id)}
    return {"runs": runs}


@router.get("/settings")
def settings_endpoint(settings: Settings = Depends(get_settings)) -> dict:
    return {
        "symbol": settings.symbol,
        "symbol_aliases": settings.symbol_list,
        "data_mode": settings.data_mode,
        "mode_label": {
            "SYNTHETIC": "Synthetic test data (not real prices)",
            "HISTORICAL": "Historical CSV data",
            "LIVE": "Live data",
        }[settings.data_mode],
        "indicators": {
            "ema_fast": settings.ema_fast,
            "ema_mid": settings.ema_mid,
            "ema_slow": settings.ema_slow,
            "rsi_period": settings.rsi_period,
            "atr_period": settings.atr_period,
        },
        "filters": {
            "max_spread_points": settings.max_spread_points,
            "min_atr_points": settings.min_atr_points,
            "max_atr_points": settings.max_atr_points,
            "swing_lookback": settings.swing_lookback,
            "m5_confirm_threshold": settings.m5_confirm_threshold,
        },
        "risk": {
            "reward_risk": settings.reward_risk,
            "atr_stop_multiplier": settings.atr_stop_multiplier,
            "risk_percent": settings.risk_percent,
            "max_daily_loss_percent": settings.max_daily_loss_percent,
            "max_consecutive_losses": settings.max_consecutive_losses,
            "signal_expiry_minutes": settings.signal_expiry_minutes,
        },
        "strategy_direction": {
            "rsi_long_min": settings.rsi_long_min,
            "rsi_short_max": settings.rsi_short_max,
        },
        "disclaimer": (
            "Thresholds are configurable heuristics, not guaranteed-proven "
            "parameters."
        ),
    }


def _repo(settings: Settings) -> Repository:
    return Repository(settings.database_url)