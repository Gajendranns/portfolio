"""Event-driven walk-forward backtest on M5 with H1/M15 alignment.

Only completed candles that were available at each simulated decision time are
used (no look-ahead). SL/TP collision in one candle is resolved *against* the
trader (stop assumed hit). Breathing costs: round-trip spread + slippage.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional

import pandas as pd

from ..data.base import TIMEFRAME_MINUTES, DataMode
from ..indicators.cpr import previous_day_cpr
from ..indicators.technical import add_core_indicators
from ..strategy import signal_engine
from ..strategy.signal_engine import evaluate_signal
from .metrics import Metrics, TradeRecord, compute_metrics


@dataclass
class BacktestConfig:
    symbol: str = "XAUUSD"
    spread_points: float = 20.0
    slippage_points: float = 5.0
    commission_price_points: float = 0.0
    max_hold_bars: int = 48            # M5 bars of max holding time
    require_alignment: bool = True
    window: int = 1500                 # max candles passed to each decision


@dataclass
class BacktestResult:
    metrics: Metrics = field(default_factory=lambda: compute_metrics([]))
    trades: List[TradeRecord] = field(default_factory=list)
    equity_curve: List[dict] = field(default_factory=list)
    from_time: Optional[str] = None
    to_time: Optional[str] = None
    data_mode: str = "HISTORICAL"
    data_source: str = ""
    warnings: List[str] = field(default_factory=list)
    cfg: dict = field(default_factory=dict)

    def to_dict(self, with_trades: bool = False) -> dict:
        out = {
            "metrics": self.metrics.to_dict(),
            "from_time": self.from_time,
            "to_time": self.to_time,
            "data_mode": self.data_mode,
            "data_source": self.data_source,
            "warnings": self.warnings,
            "config": self.cfg,
            "equity_curve": self.equity_curve[-2000:],
        }
        if with_trades:
            out["trades"] = [t.to_dict() for t in self.trades[-500:]]
        return out


def _pt(dt: datetime | pd.Timestamp):
    t = pd.Timestamp(dt)
    if t.tzinfo is None:
        t = t.tz_localize("UTC")
    return t.tz_convert("UTC")


def _as_of(frame: pd.DataFrame, t: pd.Timestamp, tf_min: int) -> pd.DataFrame:
    """Rows whose candle is *completed* at or before time ``t``."""
    if frame is None or len(frame) == 0:
        return frame
    end = t - pd.Timedelta(minutes=tf_min)
    return frame[frame.index <= end]


def _split_periods(
    start: datetime, end: datetime
) -> List[tuple[datetime, datetime]]:
    """Chronological train/validation/test splits (70/15/15)."""
    total = end - start
    a = start + total * 0.70
    b = start + total * 0.85
    return [(start, a), (a, b), (b, end)]


def run_backtest(
    *,
    m5: pd.DataFrame,
    m15: pd.DataFrame,
    h1: pd.DataFrame,
    settings,
    cfg: BacktestConfig | None = None,
    data_mode: str = "HISTORICAL",
    data_source: str = "csv",
    start: Optional[datetime] = None,
    end: Optional[datetime] = None,
    ensure_complete_only: bool = True,
) -> BacktestResult:
    cfg = cfg or BacktestConfig()
    res = BacktestResult(data_mode=data_mode, data_source=data_source)
    res.cfg = {
        "spread_points": cfg.spread_points,
        "slippage_points": cfg.slippage_points,
        "commission_price_points": cfg.commission_price_points,
        "max_hold_bars": cfg.max_hold_bars,
        "symbol": cfg.symbol,
    }

    if m5 is None or len(m5) == 0:
        res.warnings.append("No M5 data supplied.")
        res.metrics = compute_metrics(res.trades)
        return res

    df5 = m5.sort_index()
    if ensure_complete_only:
        df5 = df5[df5.index <= df5.index[-1]].copy()
    mode = DataMode(data_mode) if isinstance(data_mode, str) else data_mode

    if start is None:
        start = df5.index.min().to_pydatetime()
    if end is None or end > df5.index.max().to_pydatetime():
        end = df5.index.max().to_pydatetime()
    res.from_time = start.isoformat()
    res.to_time = end.isoformat()

    mask = (df5.index >= _pt(start)) & (df5.index <= _pt(end))
    df5 = df5[mask]
    if len(df5) == 0:
        res.warnings.append("No M5 candles in selected range.")
        res.metrics = compute_metrics(res.trades)
        return res

    warmup = max(
        signal_engine.MIN_CANDLES["H1"] * 2,
        signal_engine.MIN_CANDLES["M15"],
        signal_engine.MIN_CANDLES["M5"],
    )
    # precompute causal indicator columns once (safe to slice later)
    h1_i = add_core_indicators(h1.sort_index()) if h1 is not None and len(h1) else h1
    m15_i = add_core_indicators(m15.sort_index()) if m15 is not None and len(m15) else m15
    df5_i = add_core_indicators(df5)
    cum = 0.0
    peak = 0.0
    res.equity_curve.append({"time": df5.index[0].isoformat(), "equity": cum})
    trade_states: dict = {}

    for i in range(len(df5)):
        t = df5.index[i]
        # current prices from the just-closed M5 candle
        close_price = float(df5["close"].iloc[i])
        high_price = float(df5["high"].iloc[i])
        low_price = float(df5["low"].iloc[i])

        # ---- mark existing trades to market first (SL/TP) ----
        for key in list(trade_states):
            st = trade_states[key]
            if st["status"] != "open":
                continue
            entry, sl, tp = st["entry"], st["sl"], st["tp"]
            side = st["side"]
            hit_sl = low_price <= sl if side == "BUY" else high_price >= sl
            hit_tp = high_price >= tp if side == "BUY" else low_price <= tp
            if hit_sl and hit_tp:
                # collision: assume stop first (no optimistic fills)
                exit_px, status = sl, "sl"
            elif hit_sl:
                exit_px, status = sl, "sl"
            elif hit_tp:
                exit_px, status = tp, "tp"
            else:
                st["bars_held"] += 1
                if st["bars_held"] >= cfg.max_hold_bars:
                    exit_px, status = close_price, "time_exit"
                else:
                    continue
            raw = (exit_px - entry) if side == "BUY" else (entry - exit_px)
            cost = st["cost_per_unit"]
            pnl = raw - cost
            tr = TradeRecord(
                side=side,
                entry_time=st["entry_time"],
                exit_time=t.isoformat(),
                entry_price=entry,
                exit_price=exit_px,
                pnl=raw,
                pnl_after_costs=pnl,
                status=status,
                h1_condition=st["h1_condition"],
            )
            res.trades.append(tr)
            cum += pnl
            peak = max(peak, cum)
            res.equity_curve.append({"time": t.isoformat(), "equity": cum})
            del trade_states[key]

        # ---- decision (only when enough history, skip warmup) ----
        if i < warmup:
            continue
        ts = pd.Timestamp(t)
        h1_so = _as_of(h1_i, ts, TIMEFRAME_MINUTES["H1"])
        m15_so = _as_of(m15_i, ts, TIMEFRAME_MINUTES["M15"])
        m5_so = _as_of(df5_i, ts, TIMEFRAME_MINUTES["M5"])
        if len(m5_so) == 0 or len(h1_so) == 0 or len(m15_so) == 0:
            continue
        if len(h1_so) > cfg.window:
            h1_so = h1_so.iloc[-cfg.window:]
        if len(m15_so) > cfg.window:
            m15_so = m15_so.iloc[-cfg.window:]
        if len(m5_so) > cfg.window:
            m5_so = m5_so.iloc[-cfg.window:]

        cpr = previous_day_cpr(m15_so)
        quote = {
            "spread": cfg.spread_points * signal_engine.POINT_SIZE,
            "live": False,
        }
        sig = evaluate_signal(
            symbol=cfg.symbol,
            h1_i=h1_so, m15_i=m15_so, m5_i=m5_so,
            cpr=cpr,
            data_mode=mode,
            data_source=data_source,
            quote=quote,
            settings=settings,
            now=t.to_pydatetime(),
        )
        if sig.signal == "NO TRADE":
            continue

        plan_sl = sig.stop_loss
        plan_tp = sig.take_profit
        if plan_sl is None or plan_tp is None:
            continue
        h1_cond = (sig.h1_trend or {}).get("direction", "unknown")

        # avoid duplicate concurrent signal for same direction
        if any(
            st["side"] == sig.signal and st["status"] == "open"
            for st in trade_states.values()
        ):
            continue

        cost_per_unit = (
            cfg.spread_points + 2 * cfg.slippage_points
            + cfg.commission_price_points
        ) * signal_engine.POINT_SIZE
        # enter at the close of the completed signal candle (no look-ahead)
        entry_price = float(m5_so["close"].iloc[-1])
        trade_states[f"{i}_{sig.signal}"] = {
            "side": sig.signal,
            "entry": entry_price,
            "sl": plan_sl,
            "tp": plan_tp,
            "entry_time": t.isoformat(),
            "status": "open",
            "bars_held": 0,
            "cost_per_unit": cost_per_unit,
            "h1_condition": h1_cond,
        }

    res.equity_curve.append(
        {"time": df5.index[-1].isoformat(), "equity": cum}
    )
    res.metrics = compute_metrics(res.trades)
    res.warnings.extend(
        [
            "Simulated results only - not a forecast.",
            "SL/TP collision in one candle is resolved as stop-loss (conservative).",
            f"Costs: round-trip spread {cfg.spread_points:.1f} + slippage "
            f"{2 * cfg.slippage_points:.1f} + commission "
            f"{cfg.commission_price_points:.1f} price points.",
        ]
    )
    return res