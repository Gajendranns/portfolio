"""Backtest performance metrics.

All figures are simulated results. They say nothing about future performance
and must never be presented as validated probabilities.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class TradeRecord:
    side: str
    entry_time: str
    exit_time: str
    entry_price: float
    exit_price: float
    pnl: float
    pnl_after_costs: float
    status: str  # "tp" | "sl" | "time_exit"
    h1_condition: str = "unknown"

    def to_dict(self) -> dict:
        return {
            "side": self.side,
            "entry_time": self.entry_time,
            "exit_time": self.exit_time,
            "entry_price": round(self.entry_price, 5),
            "exit_price": round(self.exit_price, 5),
            "pnl": round(self.pnl, 5),
            "pnl_after_costs": round(self.pnl_after_costs, 5),
            "status": self.status,
            "h1_condition": self.h1_condition,
        }


@dataclass
class Metrics:
    total_signals: int = 0
    total_trades: int = 0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    expectancy: float = 0.0
    net_pnl: float = 0.0
    net_pnl_after_costs: float = 0.0
    max_drawdown: float = 0.0
    max_drawdown_pct: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    max_consecutive_losses: int = 0
    by_condition: dict = field(default_factory=dict)
    by_side: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "total_signals": self.total_signals,
            "total_trades": self.total_trades,
            "win_rate": round(self.win_rate, 4),
            "profit_factor": round(self.profit_factor, 4),
            "expectancy": round(self.expectancy, 5),
            "net_pnl": round(self.net_pnl, 5),
            "net_pnl_after_costs": round(self.net_pnl_after_costs, 5),
            "max_drawdown": round(self.max_drawdown, 5),
            "max_drawdown_pct": round(self.max_drawdown_pct, 4),
            "avg_win": round(self.avg_win, 5),
            "avg_loss": round(self.avg_loss, 5),
            "max_consecutive_losses": self.max_consecutive_losses,
            "by_condition": self.by_condition,
            "by_side": self.by_side,
            "disclaimer": (
                "Simulated results only. Not a forecast of future performance."
            ),
        }


def compute_metrics(trades: List[TradeRecord]) -> Metrics:
    m = Metrics()
    m.total_trades = len(trades)

    if trades:
        pnls = [t.pnl_after_costs for t in trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        m.win_rate = len(wins) / len(pnls)
        gross_win = sum(wins)
        gross_loss = -sum(losses)
        m.profit_factor = gross_win / gross_loss if gross_loss > 0 else float("inf")
        m.expectancy = sum(pnls) / len(pnls)
        m.net_pnl = sum(t.pnl for t in trades)
        m.net_pnl_after_costs = sum(t.pnl_after_costs for t in trades)
        m.avg_win = gross_win / len(wins) if wins else 0.0
        m.avg_loss = (gross_loss / len(losses)) if losses else 0.0

        peak = 0.0
        cum = 0.0
        max_dd = 0.0
        for p in pnls:
            cum += p
            peak = max(peak, cum)
            max_dd = min(max_dd, cum - peak)
        m.max_drawdown = -max_dd
        m.max_drawdown_pct = m.max_drawdown / abs(peak) if peak else 0.0

        m.max_consecutive_losses = _max_consecutive(pnls)

        for cond in {"bullish", "bearish", "sideways", "unknown"}:
            sub = [t for t in trades if t.h1_condition == cond]
            if sub:
                m.by_condition[cond] = _mini(sub)
        for side in {"BUY", "SELL"}:
            sub = [t for t in trades if t.side == side]
            if sub:
                m.by_side[side] = _mini(sub)
    return m


def _max_consecutive(pnls: List[float]) -> int:
    best = cur = 0
    for p in pnls:
        cur = cur + 1 if p <= 0 else 0
        best = max(best, cur)
    return best


def _mini(trades: List[TradeRecord]) -> dict:
    pnls = [t.pnl_after_costs for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p <= 0]
    gross = sum(wins)
    neg = -sum(losses)
    return {
        "trades": len(trades),
        "win_rate": round(len(wins) / len(pnls), 4) if pnls else 0.0,
        "profit_factor": round(gross / neg, 4) if neg > 0 else (
            float("inf") if gross > 0 else 0.0
        ),
        "net_pnl_after_costs": round(sum(pnls), 5),
    }