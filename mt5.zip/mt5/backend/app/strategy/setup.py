"""M15 setup detection.

Combines CPR position, support/resistance, breakout-retest, momentum and
volatility into a bullish/bearish/neutral bias. Every input is a heuristic;
none is treated as a guaranteed reversal.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import pandas as pd

from ..indicators.cpr import CPR, cpr_position
from ..indicators.price_action import find_breakout_retest, support_resistance


@dataclass
class SetupResult:
    bias: str  # "bullish" | "bearish" | "none"
    score: int
    components: dict
    details: dict
    reasons: List[str] = field(default_factory=list)
    volatility_ok: bool = True

    def to_dict(self) -> dict:
        return {
            "bias": self.bias,
            "score": self.score,
            "components": self.components,
            "details": self.details,
            "reasons": self.reasons,
            "volatility_ok": self.volatility_ok,
        }


def detect_setup(
    df: pd.DataFrame,
    *,
    cpr: Optional[CPR] = None,
    swing_lookback: int = 5,
    rsi_long_min: float = 50.0,
    rsi_short_max: float = 50.0,
    min_atr_points: float = 0.0,
    max_atr_points: float = 1e9,
    breakout_lookback: int = 20,
) -> SetupResult:
    if df is None or len(df) == 0:
        return SetupResult("none", 0, {}, {}, ["No M15 data."])

    row = df.iloc[-1]
    close = float(row["close"])
    atr_val = row.get("atr")
    reasons: List[str] = []
    components: dict = {}

    # --- volatility filter (values are in price units) ---
    vol_ok = True
    if atr_val is not None and not pd.isna(atr_val):
        if atr_val < min_atr_points:
            vol_ok = False
            reasons.append(
                f"ATR {atr_val:.3f} below minimum {min_atr_points:.3f} "
                "(price units; market too quiet)."
            )
        elif atr_val > max_atr_points:
            vol_ok = False
            reasons.append(
                f"ATR {atr_val:.3f} above maximum {max_atr_points:.3f} "
                "(price units; abnormal volatility)."
            )
    components["volatility_ok"] = vol_ok

    # --- CPR position ---
    cpr_c = 0
    cpr_zone = "unknown"
    if cpr is not None:
        cpr_zone = cpr_position(close, cpr)
        if cpr_zone == "above":
            cpr_c = 1
        elif cpr_zone == "below":
            cpr_c = -1
        reasons.append(f"Price is {cpr_zone} the previous-day CPR.")
    components["cpr"] = cpr_c

    # --- support / resistance + breakout-retest ---
    levels = support_resistance(df, swing_lookback)
    brk_c = 0
    nearest_res = min(
        [r for r in levels["resistance"] if r >= close],
        default=None,
    )
    nearest_sup = max(
        [s for s in levels["support"] if s <= close],
        default=None,
    )
    if nearest_res is not None and find_breakout_retest(
        df, nearest_res, "bullish", breakout_lookback
    ):
        brk_c = 1
        reasons.append(f"Bullish breakout-retest of resistance {nearest_res:.2f}.")
    elif nearest_sup is not None and find_breakout_retest(
        df, nearest_sup, "bearish", breakout_lookback
    ):
        brk_c = -1
        reasons.append(f"Bearish breakout-retest of support {nearest_sup:.2f}.")
    components["breakout_retest"] = brk_c

    # --- momentum ---
    mom_c = 0
    hist = row.get("macd_hist")
    rsi = row.get("rsi")
    if not pd.isna(hist) and not pd.isna(rsi):
        if hist > 0 and rsi >= rsi_long_min:
            mom_c = 1
            reasons.append("M15 momentum bullish (MACD hist > 0, RSI >= mid).")
        elif hist < 0 and rsi <= rsi_short_max:
            mom_c = -1
            reasons.append("M15 momentum bearish (MACD hist < 0, RSI <= mid).")
    components["momentum"] = mom_c

    # --- EMA alignment ---
    ema_c = 0
    ef, em = row.get("ema_fast"), row.get("ema_mid")
    if not pd.isna(ef) and not pd.isna(em):
        ema_c = 1 if ef > em else -1
    components["ema"] = ema_c

    total = cpr_c + brk_c + mom_c + ema_c
    if not vol_ok:
        bias = "none"
    elif total > 0:
        bias = "bullish"
    elif total < 0:
        bias = "bearish"
    else:
        bias = "none"

    details = {
        "close": round(close, 5),
        "atr": _num(atr_val),
        "rsi": _num(rsi),
        "macd_hist": _num(hist),
        "cpr_zone": cpr_zone,
        "cpr": cpr.to_dict() if cpr else None,
        "nearest_resistance": _num(nearest_res),
        "nearest_support": _num(nearest_sup),
        "support": [round(x, 5) for x in levels["support"]],
        "resistance": [round(x, 5) for x in levels["resistance"]],
    }
    return SetupResult(bias, total, components, details, reasons, vol_ok)


def _num(v):
    if v is None or pd.isna(v):
        return None
    return round(float(v), 5)
