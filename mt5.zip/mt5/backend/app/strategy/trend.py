"""H1 trend confirmation.

The trend is classified as bullish / bearish / sideways. When structure,
momentum and EMA alignment disagree we return SIDEWAYS rather than forcing a
direction.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import pandas as pd

from ..indicators.price_action import swing_points


@dataclass
class TrendResult:
    direction: str  # "bullish" | "bearish" | "sideways"
    score: int
    components: dict
    indicators: dict
    reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "direction": self.direction,
            "score": self.score,
            "components": self.components,
            "indicators": self.indicators,
            "reasons": self.reasons,
        }


def _ema_component(row: pd.Series) -> int:
    ef, em, es = row["ema_fast"], row["ema_mid"], row["ema_slow"]
    if pd.isna(es):
        # not enough history for the slow EMA: use fast/mid only
        if pd.isna(em):
            return 0
        return 1 if ef > em else -1
    if ef > em > es:
        return 1
    if ef < em < es:
        return -1
    return 0


def _price_structure(df: pd.DataFrame, lookback: int) -> int:
    marked = swing_points(df, lookback)
    sh = marked[marked["swing_high"]]["high"].tolist()
    sl = marked[marked["swing_low"]]["low"].tolist()
    if len(sh) >= 2 and len(sl) >= 2:
        if sh[-1] > sh[-2] and sl[-1] > sl[-2]:
            return 1
        if sh[-1] < sh[-2] and sl[-1] < sl[-2]:
            return -1
    return 0


def _momentum_component(row: pd.Series, rsi_long_min: float, rsi_short_max: float) -> int:
    hist = row.get("macd_hist")
    rsi = row.get("rsi")
    if pd.isna(hist) or pd.isna(rsi):
        return 0
    if hist > 0 and rsi >= rsi_long_min:
        return 1
    if hist < 0 and rsi <= rsi_short_max:
        return -1
    return 0


def classify_trend(
    df: pd.DataFrame,
    *,
    swing_lookback: int = 5,
    rsi_long_min: float = 50.0,
    rsi_short_max: float = 50.0,
) -> TrendResult:
    """df must carry EMA/RSI/MACD columns and at least a few rows."""
    if df is None or len(df) == 0:
        return TrendResult("sideways", 0, {}, {}, ["No H1 data."])
    row = df.iloc[-1]
    ema_c = _ema_component(row)
    struct_c = _price_structure(df, swing_lookback)
    mom_c = _momentum_component(row, rsi_long_min, rsi_short_max)
    total = ema_c + struct_c + mom_c

    if total > 0:
        direction = "bullish"
    elif total < 0:
        direction = "bearish"
    else:
        direction = "sideways"

    reasons = [
        f"EMA structure vote: {ema_c:+d}",
        f"Price structure vote: {struct_c:+d}",
        f"Momentum vote: {mom_c:+d}",
    ]
    if direction == "sideways":
        reasons.append("Signals conflict or are neutral -> no directional trend.")

    indicators = {
        "ema_fast": _num(row.get("ema_fast")),
        "ema_mid": _num(row.get("ema_mid")),
        "ema_slow": _num(row.get("ema_slow")),
        "rsi": _num(row.get("rsi")),
        "macd_hist": _num(row.get("macd_hist")),
        "close": _num(row.get("close")),
    }
    return TrendResult(direction, total, {
        "ema": ema_c, "structure": struct_c, "momentum": mom_c,
    }, indicators, reasons)


def _num(v):
    if v is None or pd.isna(v):
        return None
    return round(float(v), 5)
