"""Risk management for a signal-only tool.

Nothing here executes trades. It computes stop/target, position size and
tracking limits so the user can make an informed manual decision.

Broker contract specifications differ. XAUUSD defaults below (100 oz/lot) are
placeholders - VERIFY with VT Markets before sizing a real trade.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import List, Optional


@dataclass
class ContractSpec:
    symbol: str = "XAUUSD"
    contract_size: float = 100.0          # units per 1.00 lot (VERIFY)
    tick_size: float = 0.01               # minimum price increment (VERIFY)
    tick_value: float = 1.0               # account ccy per tick per lot (VERIFY)
    digits: int = 2
    min_lot: float = 0.01
    max_lot: float = 100.0
    lot_step: float = 0.01

    @property
    def value_per_price_unit_per_lot(self) -> float:
        """Money per 1.0 price move per 1.00 lot."""
        return self.tick_value * (1.0 / self.tick_size)

    def to_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "contract_size": self.contract_size,
            "tick_size": self.tick_size,
            "tick_value": self.tick_value,
            "digits": self.digits,
            "min_lot": self.min_lot,
            "max_lot": self.max_lot,
            "lot_step": self.lot_step,
            "value_per_price_unit_per_lot": self.value_per_price_unit_per_lot,
            "note": "Default XAUUSD specs are placeholders - verify with your broker.",
        }


@dataclass
class TradePlan:
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    stop_distance: float
    risk_reward: float
    atr: Optional[float]

    def to_dict(self) -> dict:
        return {
            "direction": self.direction,
            "entry": round(self.entry, 5),
            "stop_loss": round(self.stop_loss, 5),
            "take_profit": round(self.take_profit, 5),
            "stop_distance": round(self.stop_distance, 5),
            "risk_reward": round(self.risk_reward, 2),
            "atr": round(self.atr, 5) if self.atr is not None else None,
        }


def build_trade_plan(
    *,
    direction: str,
    entry: float,
    atr: float,
    atr_stop_multiplier: float = 1.5,
    reward_risk: float = 2.0,
) -> TradePlan:
    """ATR-based stop and reward-risk target."""
    if atr is None or atr <= 0:
        raise ValueError("ATR must be positive to build a trade plan.")
    stop_distance = atr * atr_stop_multiplier
    if direction == "BUY":
        sl = entry - stop_distance
        tp = entry + stop_distance * reward_risk
    elif direction == "SELL":
        sl = entry + stop_distance
        tp = entry - stop_distance * reward_risk
    else:
        raise ValueError("direction must be BUY or SELL")
    return TradePlan(
        direction=direction,
        entry=entry,
        stop_loss=sl,
        take_profit=tp,
        stop_distance=stop_distance,
        risk_reward=reward_risk,
        atr=atr,
    )


def position_size(
    *,
    equity: float,
    risk_percent: float,
    stop_distance: float,
    spec: ContractSpec,
) -> dict:
    """Position size in lots. Signals only - never auto-executes."""
    if stop_distance <= 0:
        raise ValueError("stop_distance must be positive.")
    risk_amount = equity * (risk_percent / 100.0)
    per_lot_risk = stop_distance * spec.value_per_price_unit_per_lot
    if per_lot_risk <= 0:
        return {"lots": 0.0, "risk_amount": risk_amount, "note": "Invalid spec."}
    raw_lots = risk_amount / per_lot_risk
    steps = max(1, round(spec.lot_step / 0.01))
    lots = round(raw_lots / spec.lot_step) * spec.lot_step
    lots = max(spec.min_lot, min(spec.max_lot, round(lots, 2)))
    return {
        "lots": round(lots, 2),
        "raw_lots": round(raw_lots, 4),
        "risk_amount": round(risk_amount, 2),
        "per_lot_risk": round(per_lot_risk, 2),
        "spec": spec.to_dict(),
    }


class RiskTracker:
    """Tracks simulated (paper) results to enforce loss limits.

    This only ever records signals/trades the user chooses to simulate; it does
    not place orders.
    """

    def __init__(
        self,
        *,
        max_daily_loss_percent: float = 3.0,
        max_consecutive_losses: int = 4,
        starting_equity: float = 10000.0,
    ) -> None:
        self.max_daily_loss_percent = max_daily_loss_percent
        self.max_consecutive_losses = max_consecutive_losses
        self.starting_equity = starting_equity
        self.equity = starting_equity
        self.consecutive_losses = 0
        self._daily_pnl: dict[date, float] = {}
        self._open_keys: set[str] = set()

    def record_result(self, pnl: float, when: Optional[datetime] = None) -> None:
        when = when or datetime.now(timezone.utc)
        d = when.date()
        self._daily_pnl[d] = self._daily_pnl.get(d, 0.0) + pnl
        self.equity += pnl
        if pnl < 0:
            self.consecutive_losses += 1
        elif pnl > 0:
            self.consecutive_losses = 0

    def daily_pnl(self, when: Optional[datetime] = None) -> float:
        when = when or datetime.now(timezone.utc)
        return self._daily_pnl.get(when.date(), 0.0)

    def daily_loss_limit_hit(self, when: Optional[datetime] = None) -> bool:
        base = self.equity - self.daily_pnl(when)
        limit = base * (self.max_daily_loss_percent / 100.0)
        return self.daily_pnl(when) <= -limit

    def blocked_reasons(self, when: Optional[datetime] = None) -> List[str]:
        out = []
        if self.daily_loss_limit_hit(when):
            out.append("Daily loss limit reached (simulated).")
        if self.consecutive_losses >= self.max_consecutive_losses:
            out.append(
                f"Consecutive loss limit reached ({self.consecutive_losses})."
            )
        return out

    # --- duplicate-signal prevention ---
    @staticmethod
    def signal_key(symbol: str, timeframe: str, direction: str, candle_time) -> str:
        return f"{symbol}:{timeframe}:{direction}:{candle_time}"

    def is_duplicate(self, key: str) -> bool:
        return key in self._open_keys

    def register(self, key: str) -> None:
        self._open_keys.add(key)
