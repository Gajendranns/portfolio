"""Multi-timeframe signal engine (H1 trend -> M15 setup -> M5 confirmation).

Signal-oriented and heuristic. `confidence` is an uncalibrated model score,
NOT a validated probability.

``generate_signal`` takes raw frames and computes indicators before
evaluating. ``evaluate_signal`` expects frames that already carry indicator
columns - used by the backtest engine which precomputes indicators once
(EWM/rolling indicators are causal, so slicing is look-ahead-safe).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import pandas as pd

from ..data.base import DataMode
from ..indicators.cpr import CPR
from ..indicators.price_action import (
    is_bearish_engulfing,
    is_bearish_rejection,
    is_bullish_engulfing,
    is_bullish_rejection,
    swing_points,
)
from ..indicators.technical import add_core_indicators
from .risk import RiskTracker, build_trade_plan
from .setup import SetupResult, detect_setup
from .trend import TrendResult, classify_trend

MIN_CANDLES = {"H1": 60, "M15": 80, "M5": 120}
POINT_SIZE = 0.01  # XAUUSD: 1 point == 1 cent of price (verify for broker)


@dataclass
class Signal:
    symbol: str
    signal: str  # BUY | SELL | NO TRADE
    signal_timestamp: Optional[str]
    data_timestamp: Optional[str]
    data_source: str
    data_mode: str
    h1_trend: Optional[dict]
    m15_bias: Optional[str]
    m15_setup: Optional[dict]
    entry: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    risk_reward: Optional[float]
    indicator_values: dict
    spread: Optional[float]
    atr: Optional[float]
    confidence: float
    confidence_label: str
    expiry: Optional[str]
    invalidation_conditions: List[str]
    supporting_reasons: List[str] = field(default_factory=list)
    rejection_reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "signal": self.signal,
            "signal_timestamp": self.signal_timestamp,
            "data_timestamp": self.data_timestamp,
            "data_source": self.data_source,
            "data_mode": self.data_mode,
            "h1_trend": self.h1_trend,
            "m15_bias": self.m15_bias,
            "m15_setup": self.m15_setup,
            "entry": self.entry,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "risk_reward": self.risk_reward,
            "indicator_values": self.indicator_values,
            "spread": self.spread,
            "atr": self.atr,
            "confidence": self.confidence,
            "confidence_label": self.confidence_label,
            "expiry": self.expiry,
            "invalidation_conditions": self.invalidation_conditions,
            "supporting_reasons": self.supporting_reasons,
            "rejection_reasons": self.rejection_reasons,
        }


def _prep(df: pd.DataFrame, _tf: str) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return df
    return add_core_indicators(df)


def _num(v):
    if v is None or pd.isna(v):
        return None
    return round(float(v), 5)


def generate_signal(
    *,
    symbol: str,
    h1: pd.DataFrame,
    m15: pd.DataFrame,
    m5: pd.DataFrame,
    cpr: Optional[CPR],
    data_mode: DataMode,
    data_source: str,
    quote: Optional[dict],
    settings,
    risk_tracker: Optional[RiskTracker] = None,
    now: Optional[datetime] = None,
) -> Signal:
    h1_i = _prep(h1, "H1")
    m15_i = _prep(m15, "M15")
    m5_i = _prep(m5, "M5")
    return evaluate_signal(
        symbol=symbol, h1_i=h1_i, m15_i=m15_i, m5_i=m5_i, cpr=cpr,
        data_mode=data_mode, data_source=data_source, quote=quote,
        settings=settings, risk_tracker=risk_tracker, now=now,
    )


def evaluate_signal(
    *,
    symbol: str,
    h1_i: pd.DataFrame,
    m15_i: pd.DataFrame,
    m5_i: pd.DataFrame,
    cpr: Optional[CPR],
    data_mode: DataMode,
    data_source: str,
    quote: Optional[dict],
    settings,
    risk_tracker: Optional[RiskTracker] = None,
    now: Optional[datetime] = None,
) -> Signal:
    now = now or datetime.now(timezone.utc)
    reject: List[str] = []
    support: List[str] = []

    def no_trade(*args) -> Signal:
        return Signal(
            symbol=symbol, signal="NO TRADE",
            signal_timestamp=now.isoformat(),
            data_timestamp=_last_ts(m5_i, m15_i, h1_i),
            data_source=data_source, data_mode=data_mode.value,
            h1_trend=None, m15_bias=None, m15_setup=None,
            entry=None, stop_loss=None, take_profit=None, risk_reward=None,
            indicator_values={}, spread=None, atr=None,
            confidence=0.0,
            confidence_label="uncalibrated heuristic score - not a probability",
            expiry=None, invalidation_conditions=[],
            rejection_reasons=list(args),
        )

    # ------------------------------------------------------------- guards
    if h1_i is None or len(h1_i) < MIN_CANDLES["H1"]:
        return no_trade(f"Not enough H1 candles "
                        f"({0 if h1_i is None else len(h1_i)}/{MIN_CANDLES['H1']}).")
    if m15_i is None or len(m15_i) < MIN_CANDLES["M15"]:
        return no_trade(f"Not enough M15 candles "
                        f"({0 if m15_i is None else len(m15_i)}/{MIN_CANDLES['M15']}).")
    if m5_i is None or len(m5_i) < MIN_CANDLES["M5"]:
        return no_trade(f"Not enough M5 candles "
                        f"({0 if m5_i is None else len(m5_i)}/{MIN_CANDLES['M5']}).")

    # ------------------------------------------------------------- data checks
    spread = quote.get("spread") if quote else None
    if spread is None:
        spreads = m5_i["spread"].dropna()
        spread = float(spreads.iloc[-1]) if len(spreads) else None
    if spread is not None and spread > settings.max_spread_points * POINT_SIZE:
        spread_pts = spread / POINT_SIZE
        return no_trade(
            f"Spread {spread_pts:.2f} points exceeds maximum "
            f"{settings.max_spread_points:.2f} points."
        )

    atr = _num(m5_i["atr"].iloc[-1]) if not m5_i["atr"].isna().iloc[-1] else None
    min_atr = settings.min_atr_points * POINT_SIZE
    max_atr = settings.max_atr_points * POINT_SIZE
    if atr is None:
        return no_trade("ATR unavailable on M5.")
    if atr < min_atr:
        return no_trade(
            f"ATR {atr:.2f} below safe minimum "
            f"{settings.min_atr_points:.2f} points (market too quiet)."
        )
    if atr > max_atr:
        return no_trade(
            f"ATR {atr:.2f} above safe maximum "
            f"{settings.max_atr_points:.2f} points (abnormal volatility)."
        )

    # ------------------------------------------------------------- H1 trend
    trend = classify_trend(
        h1_i,
        swing_lookback=settings.swing_lookback,
        rsi_long_min=settings.rsi_long_min,
        rsi_short_max=settings.rsi_short_max,
    )

    # ------------------------------------------------------------- M15 setup
    setup = detect_setup(
        m15_i,
        cpr=cpr,
        swing_lookback=settings.swing_lookback,
        rsi_long_min=settings.rsi_long_min,
        rsi_short_max=settings.rsi_short_max,
        min_atr_points=min_atr,
        max_atr_points=max_atr,
    )
    if not setup.volatility_ok:
        return Signal(
            symbol=symbol, signal="NO TRADE",
            signal_timestamp=now.isoformat(),
            data_timestamp=_last_ts(m5_i, m15_i, h1_i),
            data_source=data_source, data_mode=data_mode.value,
            h1_trend=trend.to_dict(), m15_bias=setup.bias,
            m15_setup=setup.to_dict(),
            entry=None, stop_loss=None, take_profit=None, risk_reward=None,
            indicator_values=_inds(m5_i, spread, atr),
            spread=spread, atr=atr,
            confidence=0.0,
            confidence_label="uncalibrated heuristic score - not a probability",
            expiry=None, invalidation_conditions=[],
            rejection_reasons=setup.reasons,
        )

    # ------------------------------------------------------------- M5 confirm
    ms = _m5_confirmation(m5_i, settings.m5_confirm_threshold)

    # ------------------------------------------------------------- decision
    direction = None
    if trend.direction == "bullish" and setup.bias == "bullish" and ms["bullish"]:
        direction = "BUY"
        support.extend([f"H1 trend: {trend.direction}", f"M15 setup: {setup.bias}"])
        support.extend(ms["reasons"])
    elif trend.direction == "bearish" and setup.bias == "bearish" and ms["bearish"]:
        direction = "SELL"
        support.extend([f"H1 trend: {trend.direction}", f"M15 setup: {setup.bias}"])
        support.extend(ms["reasons"])
    else:
        if trend.direction == "sideways":
            reject.append("No directional H1 trend confirmed.")
        elif setup.bias == "none":
            reject.append("No M15 setup confirmed.")
        else:
            reject.append(
                f"M5 confirmation does not agree with "
                f"H1={trend.direction} M15={setup.bias}."
            )
            reject.append("Timeframes conflict - no trade.")

    if direction is None:
        base = no_trade(*reject)
        base.h1_trend = trend.to_dict()
        base.m15_setup = setup.to_dict()
        base.m15_bias = setup.bias
        base.indicator_values = _inds(m5_i, spread, atr)
        base.spread = spread
        base.atr = atr
        return base

    # ------------------------------------------------------------- risk
    entry = float(m5_i["close"].iloc[-1])
    plan = build_trade_plan(
        direction=direction, entry=entry, atr=atr,
        atr_stop_multiplier=settings.atr_stop_multiplier,
        reward_risk=settings.reward_risk,
    )
    blocked = risk_tracker.blocked_reasons(now) if risk_tracker else []
    if blocked:
        base = no_trade(*blocked)
        base.h1_trend = trend.to_dict()
        base.m15_setup = setup.to_dict()
        base.m15_bias = setup.bias
        base.indicator_values = _inds(m5_i, spread, atr)
        base.spread = spread
        base.atr = atr
        base.entry = entry
        return base

    # ------------------------------------------------------------- confidence
    conf = _confidence(trend, setup, ms)
    expiry = now + timedelta(minutes=settings.signal_expiry_minutes)
    invalidations = [
        f"Signal expires at {expiry.isoformat()} - do not use later.",
        "Invalid if price moves against the entry beyond the ATR stop.",
        "Invalid if H1 trend or M15 setup flips to the opposite / sideways.",
        "Invalid if data becomes stale or the source disconnects.",
        "For manual reference only; this tool never places orders.",
    ]
    return Signal(
        symbol=symbol, signal=direction,
        signal_timestamp=now.isoformat(), data_timestamp=_last_ts(m5_i, m15_i, h1_i),
        data_source=data_source, data_mode=data_mode.value,
        h1_trend=trend.to_dict(), m15_bias=setup.bias,
        m15_setup=setup.to_dict(),
        entry=round(entry, 5), stop_loss=round(plan.stop_loss, 5),
        take_profit=round(plan.take_profit, 5),
        risk_reward=round(plan.risk_reward, 2),
        indicator_values=_inds(m5_i, spread, atr),
        spread=spread, atr=atr,
        confidence=conf,
        confidence_label="uncalibrated heuristic score - not a probability",
        expiry=expiry.isoformat(),
        invalidation_conditions=invalidations,
        supporting_reasons=support,
        rejection_reasons=[],
    )


def _last_ts(*frames: pd.DataFrame) -> Optional[str]:
    last = None
    for f in frames:
        if f is not None and len(f):
            t = f.index[-1].to_pydatetime()
            if last is None or t > last:
                last = t
    return last.isoformat() if last else None


def _inds(m5: pd.DataFrame, spread, atr) -> dict:
    row = m5.iloc[-1]
    return {
        "m5_close": _num(row.get("close")),
        "m5_rsi": _num(row.get("rsi")),
        "m5_macd_hist": _num(row.get("macd_hist")),
        "m5_ema_fast": _num(row.get("ema_fast")),
        "m5_atr": _num(atr),
        "spread": _num(spread),
    }


def _m5_confirmation(m5: pd.DataFrame, threshold: int = 3) -> dict:
    i = len(m5) - 1
    close, open_ = m5["close"].iloc[i], m5["open"].iloc[i]
    engulf_b = is_bullish_engulfing(m5, i)
    engulf_s = is_bearish_engulfing(m5, i)
    rej_b = is_bullish_rejection(m5, i)
    rej_s = is_bearish_rejection(m5, i)
    ef = m5["ema_fast"].iloc[i]
    above_ema = close > ef
    below_ema = close < ef
    marked = swing_points(m5, 5)
    sh = marked[marked["swing_high"]]["high"].tolist()
    sl = marked[marked["swing_low"]]["low"].tolist()
    above_swing = bool(sh and close > sh[-1])
    below_swing = bool(sl and close < sl[-1])

    bull_score = sum([
        int(close > open_), int(engulf_b), int(rej_b), int(above_ema), int(above_swing)
    ])
    bear_score = sum([
        int(close < open_), int(engulf_s), int(rej_s), int(below_ema), int(below_swing)
    ])
    reasons = []
    if close > open_:
        reasons.append("M5 completed candle closed bullish.")
    if close < open_:
        reasons.append("M5 completed candle closed bearish.")
    if engulf_b:
        reasons.append("M5 bullish engulfing present.")
    if engulf_s:
        reasons.append("M5 bearish engulfing present.")
    if rej_b:
        reasons.append("M5 bullish rejection (long lower wick).")
    if rej_s:
        reasons.append("M5 bearish rejection (long upper wick).")
    if above_ema:
        reasons.append("M5 close above fast EMA.")
    if below_ema:
        reasons.append("M5 close below fast EMA.")
    return {
        "bullish": bull_score >= threshold,
        "bearish": bear_score >= threshold,
        "bull_score": bull_score,
        "bear_score": bear_score,
        "reasons": reasons,
    }


def _confidence(trend: TrendResult, setup: SetupResult, ms: dict) -> float:
    votes = 0
    votes += 3 if trend.direction == "bullish" else -3 if trend.direction == "bearish" else 0
    votes += 2 if setup.bias == "bullish" else -2 if setup.bias == "bearish" else 0
    votes += 2 if ms["bullish"] else -2 if ms["bearish"] else 0
    scale = 3 + 2 + 2
    vote = abs(votes) / scale
    return round(50 + 50 * vote, 1)