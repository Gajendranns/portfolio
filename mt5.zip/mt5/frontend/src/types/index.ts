export type DataMode = "SYNTHETIC" | "HISTORICAL" | "LIVE";

export interface Candle {
  time: string;
  symbol: string;
  timeframe: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number | null;
  spread?: number | null;
}

export interface DataSourceStatus {
  provider: string;
  mode: DataMode;
  available: boolean;
  symbol: string;
  last_candle_time?: string | null;
  last_update_time?: string | null;
  is_stale?: boolean;
  fresh?: boolean;
  detail?: string;
  warnings?: string[];
}

export interface DataStatusResponse extends DataSourceStatus {
  symbols?: string[];
}

export interface MarketResponse {
  symbol: string;
  mode: DataMode;
  data_mode: DataMode;
  data_source: string;
  status: DataSourceStatus;
  candles: Record<string, Candle[]>;
  cpr?: {
    pivot: number;
    bc: number;
    tc: number;
    top: number;
    bottom: number;
    width: number;
  } | null;
  quote?: { mid?: number; live?: boolean; time?: string } | null;
  reports: Record<string, {
    is_valid: boolean;
    errors: string[];
    warnings: string[];
    n_input: number;
    n_output: number;
    n_gaps: number;
    first_time?: string;
    last_time?: string;
    timezone: string;
  }>;
  meta: Record<string, { n_candles: number; first_time?: string; last_time?: string; valid: boolean }>;
  synthetic_warning?: string | null;
}

export interface Signal {
  symbol: string;
  signal: "BUY" | "SELL" | "NO TRADE";
  signal_timestamp?: string;
  data_timestamp?: string;
  data_source?: string;
  data_mode?: DataMode;
  h1_trend?: { direction: string; indicators?: Record<string, number | null>; reasons?: string[] } | null;
  m15_bias?: string | null;
  m15_setup?: { bias: string; reasons?: string[]; details?: Record<string, unknown> } | null;
  entry?: number | null;
  stop_loss?: number | null;
  take_profit?: number | null;
  risk_reward?: number | null;
  indicator_values?: Record<string, number | null>;
  spread?: number | null;
  atr?: number | null;
  confidence?: number;
  confidence_label?: string;
  expiry?: string | null;
  invalidation_conditions?: string[];
  supporting_reasons?: string[];
  rejection_reasons?: string[];
}

export interface Metrics {
  total_trades: number;
  win_rate: number;
  profit_factor: number;
  expectancy: number;
  net_pnl: number;
  net_pnl_after_costs: number;
  max_drawdown: number;
  max_drawdown_pct: number;
  avg_win: number;
  avg_loss: number;
  max_consecutive_losses: number;
  by_condition: Record<string, Record<string, number>>;
  by_side: Record<string, Record<string, number>>;
  disclaimer: string;
}

export interface BacktestResult {
  run_id?: number | null;
  metrics: Metrics;
  trades?: Array<{
    side: string;
    entry_time: string;
    exit_time: string;
    entry_price: number;
    exit_price: number;
    pnl: number;
    pnl_after_costs: number;
    status: string;
  }>;
  equity_curve?: Array<{ time: string; equity: number }>;
  from_time?: string;
  to_time?: string;
  data_mode?: DataMode;
  warnings?: string[];
  synthetic_warning?: string | null;
}

export interface SettingsResponse {
  symbol: string;
  symbol_aliases: string[];
  data_mode: DataMode;
  mode_label?: string;
  indicators: Record<string, number>;
  filters: Record<string, number>;
  risk: Record<string, number>;
  disclaimer: string;
}