import type {
  BacktestResult,
  DataStatusResponse,
  MarketResponse,
  SettingsResponse,
  Signal,
} from "../types";

async function j<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status} ${body.slice(0, 200)}`);
  }
  return (await res.json()) as T;
}

export const getMarket = (symbol = "XAUUSD"): Promise<MarketResponse> =>
  fetch(`/api/market/${symbol}`).then((r) => j<MarketResponse>(r));

export const getLatestSignal = (symbol?: string): Promise<{ latest: Signal }> =>
  fetch(`/api/signals/latest${symbol ? `?symbol=${symbol}` : ""}`).then((r) =>
    j<{ latest: Signal }>(r),
  );

export const getSignalHistory = (limit = 50): Promise<{ history: Signal[] }> =>
  fetch(`/api/signals/history?limit=${limit}`).then((r) =>
    j<{ history: Signal[] }>(r),
  );

export const getDataStatus = (): Promise<DataStatusResponse> =>
  fetch("/api/data/status").then((r) => j<DataStatusResponse>(r));

export const getSettings = (): Promise<SettingsResponse> =>
  fetch("/api/settings").then((r) => j<SettingsResponse>(r));

export const runBacktest = (opts: Record<string, unknown> = {}): Promise<BacktestResult> =>
  fetch("/api/backtest/run", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ spread_points: 20, slippage_points: 5, ...opts }),
  }).then((r) => j<BacktestResult>(r));