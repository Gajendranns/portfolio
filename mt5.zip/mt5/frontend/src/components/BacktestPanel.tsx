import { useState } from "react";
import { runBacktest } from "../services/api";
import type { BacktestResult } from "../types";

export default function BacktestPanel() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [spread, setSpread] = useState(20);
  const [slippage, setSlippage] = useState(5);

  async function go() {
    setLoading(true);
    setError(null);
    try {
      const res = await runBacktest({
        spread_points: spread,
        slippage_points: slippage,
        with_trades: true,
      });
      setResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h3>Backtest (simulated)</h3>
      <div className="row">
        <label>
          Spread pts
          <input type="number" min={0} value={spread}
            onChange={(e) => setSpread(Number(e.target.value))} />
        </label>
        <label>
          Slippage pts
          <input type="number" min={0} value={slippage}
            onChange={(e) => setSlippage(Number(e.target.value))} />
        </label>
        <button onClick={go} disabled={loading}>
          {loading ? "Running…" : "Run backtest"}
        </button>
      </div>
      {error && <div className="err">{error}</div>}
      {result && <BacktestResultView r={result} />}
    </div>
  );
}

function BacktestResultView({ r }: { r: BacktestResult }) {
  const m = r.metrics;
  const fmt = (v: number) =>
    v === Infinity ? "∞" : v.toFixed(3);
  const cells: Array<[string, string]> = [
    ["Trades", String(m.total_trades)],
    ["Win rate", `${(m.win_rate * 100).toFixed(1)}%`],
    ["Profit factor", fmt(m.profit_factor)],
    ["Expectancy/trade", m.expectancy.toFixed(3)],
    ["Net P/L (gross)", m.net_pnl.toFixed(2)],
    ["Net P/L (after costs)", m.net_pnl_after_costs.toFixed(2)],
    ["Max drawdown", m.max_drawdown.toFixed(2)],
    ["Max consec. losses", String(m.max_consecutive_losses)],
    ["Avg win", m.avg_win.toFixed(3)],
    ["Avg loss", m.avg_loss.toFixed(3)],
  ];
  return (
    <div>
      {r.synthetic_warning && (
        <div className="warn-detail">{r.synthetic_warning}</div>
      )}
      <div className="grid3">
        {cells.map(([k, v]) => (
          <div key={k}>
            <div className="label">{k}</div>
            <div className="value">{v}</div>
          </div>
        ))}
      </div>
      {r.equity_curve && r.equity_curve.length > 1 && (
        <EquityCurve curve={r.equity_curve} />
      )}
      <div className="muted small">
        {r.from_time} → {r.to_time} · {r.data_mode}
      </div>
      <div className="muted small">{m.disclaimer}</div>
      {r.trades && r.trades.length > 0 && (
        <table className="trades">
          <thead>
            <tr>
              <th>#</th><th>Side</th><th>Status</th><th>Entry</th>
              <th>Exit</th><th>Net P/L</th>
            </tr>
          </thead>
          <tbody>
            {r.trades.slice(-50).reverse().map((t, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td>{t.side}</td>
                <td>{t.status}</td>
                <td>{t.entry_price.toFixed(2)}</td>
                <td>{t.exit_price.toFixed(2)}</td>
                <td className={t.pnl_after_costs >= 0 ? "pos" : "neg"}>
                  {t.pnl_after_costs.toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function EquityCurve({ curve }: { curve: Array<{ time: string; equity: number }> }) {
  const max = Math.max(...curve.map((p) => p.equity));
  const min = Math.min(...curve.map((p) => p.equity));
  const range = max - min || 1;
  const points = curve.map((p, idx) => `${((idx / (curve.length - 1)) * 100).toFixed(2)},${(100 - ((p.equity - min) / range) * 100).toFixed(2)}`).join(" ");
  return (
    <div className="curve">
      <div className="label">Simulated equity curve (price units)</div>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="curve-svg">
        <polyline points={points} fill="none" stroke="#4caf50" strokeWidth="0.6" />
      </svg>
    </div>
  );
}