import {
  createChart,
  ColorType,
  type UTCTimestamp,
} from "lightweight-charts";
import { useEffect, useRef } from "react";
import type { Candle } from "../types";

interface Props {
  title: string;
  candles: Candle[];
  height?: number;
}

function toUTCTime(iso: string): number {
  return Math.floor(Date.parse(iso) / 1000);
}

export default function CandleChart({ title, candles, height = 320 }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || !candles.length) return;
    const chart = createChart(el, {
      height,
      layout: {
        background: { type: ColorType.Solid, color: "#12151c" },
        textColor: "#c9d1d9",
      },
      grid: {
        vertLines: { color: "#1f242e" },
        horzLines: { color: "#1f242e" },
      },
      timeScale: { timeVisible: true, secondsVisible: false },
      rightPriceScale: { borderColor: "#1f242e" },
    });
    const series = chart.addCandlestickSeries({
      upColor: "#26a69a",
      downColor: "#ef5350",
      borderVisible: false,
      wickUpColor: "#26a69a",
      wickDownColor: "#ef5350",
    });
    series.setData(
      candles.map((c) => ({
        time: toUTCTime(c.time) as UTCTimestamp,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      })),
    );
    chart.timeScale().fitContent();
    return () => {
      chart.remove();
    };
  }, [candles, height]);

  return (
    <div className="chart-card">
      <div className="chart-title">{title}</div>
      {candles.length ? (
        <div ref={containerRef} />
      ) : (
        <div className="muted">No candles {title}</div>
      )}
    </div>
  );
}