import type { Signal } from "../types";

export default function SignalHistory({ history }: { history: Signal[] }) {
  if (!history.length) return null;
  return (
    <div className="card">
      <h3>Signal history</h3>
      <table className="trades">
        <thead>
          <tr>
            <th>Time</th><th>Signal</th><th>H1</th><th>M15</th>
            <th>Entry</th><th>R/R</th>
          </tr>
        </thead>
        <tbody>
          {history.slice(0, 30).map((s, i) => (
            <tr key={i}>
              <td>{s.signal_timestamp?.slice(0, 19)}</td>
              <td>{s.signal}</td>
              <td>{s.h1_trend?.direction ?? "–"}</td>
              <td>{s.m15_bias ?? "–"}</td>
              <td>{s.entry?.toFixed(2) ?? "–"}</td>
              <td>{s.risk_reward?.toFixed(1) ?? "–"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}