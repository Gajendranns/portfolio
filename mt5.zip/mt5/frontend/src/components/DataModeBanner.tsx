import type { DataMode } from "../types";

interface Props {
  mode: DataMode;
  syntheticWarning?: string | null;
  provider?: string;
  lastUpdate?: string | null;
  stale?: boolean;
  available?: boolean;
}

export default function DataModeBanner({
  mode,
  syntheticWarning,
  provider,
  lastUpdate,
  stale,
  available,
}: Props) {
  return (
    <div className={`mode-banner mode-${mode.toLowerCase()}`}>
      <span className="mode-chip">{mode}</span>
      {mode === "SYNTHETIC" && (
        <strong className="warn-text">
          Synthetic Test Data — Not Real Market Prices
        </strong>
      )}
      {mode === "HISTORICAL" && (
        <span>
          Historical data source: {provider || "csv"} —{" "}
          {lastUpdate ? `last candle ${lastUpdate}` : "no candles loaded"}
        </span>
      )}
      {mode === "LIVE" && (
        <span>
          {available ? "Live feed connected" : "LIVE disabled until an authorized source is configured"}
          {stale && " — WARNING: feed stale"}
        </span>
      )}
      {syntheticWarning && <div className="warn-detail">{syntheticWarning}</div>}
    </div>
  );
}