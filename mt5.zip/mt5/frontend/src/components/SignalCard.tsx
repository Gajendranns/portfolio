import type { Signal } from "../types";

export default function SignalCard({ sig }: { sig: Signal }) {
  const cls =
    sig.signal === "BUY" ? "signal-buy" : sig.signal === "SELL" ? "signal-sell" : "signal-none";
  return (
    <div className={`card signal-card ${cls}`}>
      <div className="signal-head">
        <div className="signal-badge">{sig.signal || "NO DATA"}</div>
        <div className="signal-sub">
          {sig.symbol} · {sig.data_mode} · {sig.data_source}
        </div>
      </div>

      {(sig.entry != null || sig.stop_loss != null || sig.take_profit != null) && (
        <div className="grid3">
          <div>
            <div className="label">Entry</div>
            <div className="value">{sig.entry?.toFixed(2)}</div>
          </div>
          <div>
            <div className="label">Stop loss</div>
            <div className="value">{sig.stop_loss?.toFixed(2)}</div>
          </div>
          <div>
            <div className="label">Take profit</div>
            <div className="value">{sig.take_profit?.toFixed(2)}</div>
          </div>
        </div>
      )}

      {sig.risk_reward != null && (
        <div className="row">
          <span>
            R/R <b>{sig.risk_reward}</b>
          </span>
          <span>
            Confidence <b>{sig.confidence}</b>
          </span>
          <span className="muted" title={sig.confidence_label}>
            uncalibrated score
          </span>
          {sig.atr != null && <span>ATR {sig.atr}</span>}
          {sig.spread != null && <span>Spread {sig.spread}</span>}
        </div>
      )}

      {sig.h1_trend && (
        <div className="row">
          <span>
            H1 trend <b>{sig.h1_trend.direction}</b>
          </span>
          {sig.m15_bias && (
            <span>
              M15 setup <b>{sig.m15_bias}</b>
            </span>
          )}
        </div>
      )}

      {!!sig.supporting_reasons?.length && (
        <ul className="reasons ok">
          {sig.supporting_reasons.map((r, i) => (
            <li key={i}>{r}</li>
          ))}
        </ul>
      )}
      {!!sig.rejection_reasons?.length && (
        <ul className="reasons bad">
          {sig.rejection_reasons.map((r, i) => (
            <li key={i}>{r}</li>
          ))}
        </ul>
      )}

      {!!sig.invalidation_conditions?.length && (
        <div className="muted small">
          Invalidation: {sig.invalidation_conditions.join(" · ")}
        </div>
      )}
      <div className="muted small">Signal at {sig.signal_timestamp}</div>
    </div>
  );
}