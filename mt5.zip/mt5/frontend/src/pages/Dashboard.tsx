import { useEffect, useState } from "react";
import BacktestPanel from "../components/BacktestPanel";
import CandleChart from "../components/CandleChart";
import SignalCard from "../components/SignalCard";
import SignalHistory from "../components/SignalHistory";
import DataModeBanner from "../components/DataModeBanner";
import {
  getDataStatus,
  getMarket,
  getSettings,
  getSignalHistory,
  getLatestSignal,
} from "../services/api";
import type {
  DataStatusResponse,
  MarketResponse,
  SettingsResponse,
  Signal,
} from "../types";

export default function Dashboard() {
  const [market, setMarket] = useState<MarketResponse | null>(null);
  const [status, setStatus] = useState<DataStatusResponse | null>(null);
  const [signal, setSignal] = useState<Signal | null>(null);
  const [settings, setSettings] = useState<SettingsResponse | null>(null);
  const [history, setHistory] = useState<Signal[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const [m, st, sg, se, h] = await Promise.all([
        getMarket("XAUUSD"),
        getDataStatus(),
        getLatestSignal("XAUUSD"),
        getSettings(),
        getSignalHistory(30),
      ]);
      setMarket(m);
      setStatus(st);
      setSignal(sg.latest);
      setSettings(se);
      setHistory(h.history);
      setError(null);
    } catch (e) {
      setError(
        `Backend unreachable at http://127.0.0.1:8000 — ${e instanceof Error ? e.message : e}`,
      );
    }
  }

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 30000);
    return () => clearInterval(t);
  }, []);

  const mode = status?.mode ?? market?.data_mode ?? settings?.data_mode;

  return (
    <div className="app">
      <header className="header">
        <h1>XAUUSD Signal Bot</h1>
        <span className="muted">Signal-only · no automated trading</span>
      </header>

      <DataModeBanner
        mode={mode ?? "HISTORICAL"}
        syntheticWarning={market?.synthetic_warning}
        provider={status?.provider}
        lastUpdate={status?.last_candle_time}
        stale={status?.is_stale}
        available={status?.available}
      />

      {error && <div className="err">{error}</div>}

      <div className="grid">
        <section>
          {signal && <SignalCard sig={signal} />}

          {status && (
            <div className="card">
              <h3>Data source</h3>
              <div className="row">
                <span>Provider {status.provider}</span>
                <span>{status.available ? "available" : "UNAVAILABLE"}</span>
                <span>{status.is_stale ? "stale" : "fresh"}</span>
              </div>
              {status.detail && <div className="muted small">{status.detail}</div>}
              {status.warnings?.map((w, i) => (
                <div key={i} className="muted small warn-text">⚠ {w}</div>
              ))}
            </div>
          )}

          {settings && (
            <div className="card">
              <h3>Configuration</h3>
              <div className="grid3 small">
                <div className="label">Indicators</div>
                <div className="value">
                  {Object.entries(settings.indicators)
                    .map(([k, v]) => `${k}=${v}`)
                    .join(" · ")}
                </div>
                <div className="label">Filters</div>
                <div className="value">
                  {Object.entries(settings.filters)
                    .map(([k, v]) => `${k}=${v}`)
                    .join(" · ")}
                </div>
                <div className="label">Risk</div>
                <div className="value">
                  {Object.entries(settings.risk)
                    .map(([k, v]) => `${k}=${v}`)
                    .join(" · ")}
                </div>
              </div>
              <div className="muted small">{settings.disclaimer}</div>
            </div>
          )}

          <BacktestPanel />
          <SignalHistory history={history} />
        </section>

        <section className="charts">
          <CandleChart
            title="XAUUSD H1 — trend confirmation"
            candles={market?.candles.H1 ?? []}
          />
          <CandleChart
            title="XAUUSD M15 — setup detection"
            candles={market?.candles.M15 ?? []}
          />
          <CandleChart
            title="XAUUSD M5 — entry confirmation"
            candles={market?.candles.M5 ?? []}
          />
        </section>
      </div>
    </div>
  );
}