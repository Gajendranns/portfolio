# Data access for VT Markets (MT5)

Findings from research (recorded so this project never invents a data source):

1. **VT Markets has no public retail REST market-data API.** Market data flows
   through the proprietary MT4/MT5 desktop/web terminal platforms.
2. **The MT5 Web Terminal exposes no programmatic candle export** — it is a
   read-only web UI; no browser API or scraping endpoint is documented or
   intended for retrieval.
3. The Python `MetaTrader5` pip package requires **a locally installed and
   running MT5 *desktop* terminal** (Windows/macOS). It cannot talk to the
   web terminal or to a headless Linux server.
4. Third-party "MT5 bridge" services re-host your credentials and are
   **unauthorized** and risky — not used here.

## Consequence

- Baseline = **CSV provider** (`HISTORICAL` / `SYNTHETIC`).
- `BrokerProvider` (`LIVE`) is deliberately disabled until an **authorized,
  verifiable** source is configured (e.g., export from your own licensed
  terminal, verified and imported as CSVs).
- The backend will not run against fake "live" prices; anything not proven
  real is labeled synthetic/historical in every response.

## Switching modes

See README → "Data modes". Drop verified exports into `data/historical`
using the documented CSV schema and run with `DATA_MODE=HISTORICAL`.